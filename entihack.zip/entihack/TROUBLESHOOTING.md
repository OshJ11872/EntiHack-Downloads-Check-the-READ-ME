# Troubleshooting

Common issues when setting up and running Entihack, based on real problems people have hit.

---

## "Double-clicking Start_Entihack.command does nothing" (Mac)

macOS blocks newly-downloaded scripts from running by double-click the first time, as a security measure — this isn't specific to Entihack.

**Fix:**
1. Right-click (not double-click) `Start_Entihack.command`.
2. Choose **Open** from the menu.
3. A popup will appear warning it's from an unidentified developer — click **Open** to confirm.
4. After this one-time confirmation, regular double-clicking will work normally going forward.

If right-click → Open still doesn't show a popup or do anything, the file may have lost its "executable" permission during download/unzip. Open Terminal, navigate to the folder, and run:
```bash
chmod +x Start_Entihack.command Stop_Entihack.command
```
Then try again.

---

## "Double-clicking Start_Entihack.bat does nothing, or a window flashes and closes" (Windows)

Two separate common causes:

**1. Python isn't installed, or isn't on your PATH.** Install it from
[python.org](https://python.org) — during installation, check the box
labeled **"Add Python to PATH"** (unchecked by default). If you skip this,
the window will flash open and closed almost instantly because the very
first command fails.

**2. Windows SmartScreen blocked it.** If you see "Windows protected your
PC," click **More info**, then **Run anyway**. This is standard Windows
behavior for any downloaded `.bat` file, not specific to Entihack.

**To see the actual error instead of a window that closes instantly:**
1. Open Command Prompt (Start menu → type `cmd` → Enter).
2. Type `cd ` (with a trailing space), then drag the `entihack` folder from
   File Explorer into the Command Prompt window to autofill the path, then
   press Enter.
3. Run:
   ```
   Start_Entihack.bat
   ```
Since this runs it inside a window that stays open, you'll see the real
error message instead of a flash-and-close.

---

## "No terminal window opened at all" (Mac/Linux)

If nothing visibly happens — no window, no error — the most reliable fix is to run it manually instead of relying on double-click:

1. Open the **Terminal** app (Mac: Spotlight, `Cmd+Space`, type "Terminal." Linux: your distro's terminal app).
2. Type `cd ` (with a trailing space), then drag the `entihack` folder into the terminal window — this autofills the correct path. Press Enter.
3. Run:
   ```bash
   bash Start_Entihack.command      # Mac
   bash Start_Entihack_Linux.sh     # Linux
   ```
This bypasses double-click entirely and will show you any error directly in the terminal instead of failing silently.

---

## Setting up on a Chromebook (ChromeOS)

ChromeOS doesn't run `.command` or `.sh` files by double-click the way Mac/Linux desktops do — you need its Linux developer environment first.

1. **Enable Linux**: Settings → Advanced → Developer → "Linux development environment" → turn it on (one-time setup, takes a few minutes, downloads a real Linux container).
2. **Get the files into Linux**: open the Files app, find the `entihack` folder (wherever you downloaded/unzipped it), and either move or copy it into the **"Linux files"** location shown in the Files app sidebar. Anything outside that location isn't visible to the Linux container.
3. **Open the Terminal app** that the Linux setup added to your app launcher.
4. Navigate into the folder and run it:
   ```bash
   cd entihack
   bash Start_Entihack_Linux.sh
   ```

**Common ChromeOS-specific issues:**
- **"cd: entihack: No such file or directory"** — you're not inside the "Linux files" location, or the folder didn't actually copy there. Check the Files app again; it should show a matching folder under "Linux files."
- **"bash: Start_Entihack_Linux.sh: Permission denied"** — run
  `chmod +x Start_Entihack_Linux.sh` first, then try again.
- **The dashboard doesn't open automatically in the browser** — this is expected on ChromeOS (the auto-open feature relies on `xdg-open`, which isn't always present in the Linux container). Just open Chrome yourself and go to `http://localhost:5000`.

---

## "Address already in use" errors (Mac/Linux)

This means a previous run of Entihack (or something else) is still holding onto the ports it needs (2222, 8080, 8888, 5050). It usually happens if you closed the terminal window without properly stopping the servers first.

**Fix — stop everything cleanly, then restart:**
```bash
bash Stop_Entihack.command        # Mac
bash Stop_Entihack_Linux.sh       # Linux/ChromeOS
```
If that doesn't fully clear it, force-stop each process directly:
```bash
pkill -f "python3 honeypot.py"
pkill -f "python3 tarpit.py"
pkill -f "python3 api.py"
pkill -f "python3 dashboard.py"
```
Then run the start script again.

**To check if a specific port is actually free before restarting:**
```bash
lsof -i :8080
```
(Replace 8080 with whichever port is complaining.) If this prints nothing, the port is free. If it prints a process, note the PID (second column) and stop it with `kill <PID>`.

## "Address already in use" / port conflict errors (Windows)

Same underlying issue as above — something is already holding onto the port. Windows doesn't have `lsof`, so use:
```
netstat -ano | findstr :8080
```
(Replace 8080 with whichever port is complaining.) The last column is the PID. Stop it with:
```
taskkill /PID <that number> /F
```
Then run `Start_Entihack.bat` again. Or, more simply, just run `Stop_Entihack.bat` first, which handles this for you in most cases.

---

## "The log files are blank / don't exist"

Run these to check what's actually there (Mac/Linux):
```bash
ls -la logs_*.txt
cat logs_honeypot.txt logs_tarpit.txt logs_api.txt
```
On Windows (Command Prompt):
```
dir logs_*.txt
type logs_honeypot.txt
type logs_tarpit.txt
type logs_api.txt
```

- **Files don't exist at all** → the startup script didn't get far enough to start them, usually because the `pip install` step earlier in the script failed or hung. Try running it manually to see the real error:
  ```bash
  pip install -r requirements.txt --break-system-packages
  ```
  (On Windows, drop `--break-system-packages` — it's a Mac/Linux-specific flag: `pip install -r requirements.txt`.)
- **Files exist but are empty (0 bytes)** → the process crashed before it could print anything, almost always a missing Python package. Run the affected script directly to see the real traceback:
  ```bash
  python3 honeypot.py        # Mac/Linux
  python honeypot.py         # Windows (usually 'python', not 'python3')
  ```

---

## "ModuleNotFoundError" (e.g. "No module named 'flask'")

A required package didn't install.

**Mac/Linux:**
```bash
pip install -r requirements.txt --break-system-packages
```
If `pip` isn't recognized, try `pip3` instead.

**Windows:**
```
pip install -r requirements.txt
```
If `pip` isn't recognized, try `py -m pip install -r requirements.txt` instead.

If you're on a Mac with a very locked-down Python install, you may need a virtual environment:
```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

---

## "Dashboard opens but shows no captures"

This is expected if nothing has actually connected to the honeypot or tarpit yet — it doesn't generate fake activity on its own. Test it against yourself:
```bash
curl http://localhost:8080/
curl http://localhost:8888/test
```
Refresh `http://localhost:5000` after — you should see one or two new entries within a couple of seconds. If you still see nothing after that, check `logs_honeypot.txt` and `logs_dashboard.txt` for errors, and confirm both processes are actually running:
```bash
curl http://localhost:8080/ -v
```
"Connection refused" means the honeypot isn't actually running (see the "Address already in use" and "blank logs" sections above).

---

## "The Block button doesn't work in the live viewer"

This means no API key is configured yet (block/unblock requires one; viewing data does not). Set one:
```bash
cp api_key.txt.example api_key.txt
```
Then open `api_key.txt` in any text editor and type any text you want on its own line below the `#PUT YOUR KEY HERE` comment, save, and restart `api.py`. Paste that same key into the live viewer's "API key" field when connecting.

You can confirm whether a key is currently active without opening the viewer:
```bash
curl http://localhost:5050/api/health
```
Look for `"auth_configured":true` — if it says `false`, no key is set yet.

---

## General health check (any platform)

Run all of these — if each returns something (even a small fake page), that service is alive:
```bash
curl http://localhost:8080/          # honeypot (fake HTTP)
curl http://localhost:8888/anything  # tarpit
curl http://localhost:5050/api/health  # live API
curl -I http://localhost:5000         # dashboard
```
"Connection refused" on any of these means that specific service isn't running — check its log file and the sections above for the likely cause.
