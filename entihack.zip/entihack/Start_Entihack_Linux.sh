#!/bin/bash
# Start_Entihack_Linux.sh
#
# On a Linux desktop (or a Chromebook's Linux/Crostini container), most file
# managers will run this if you double-click it and choose "Run" or "Run in
# Terminal" (exact wording depends on your file manager — Nautilus, Files,
# Dolphin, etc. all support this). If double-clicking just opens it as text
# instead, right-click -> Properties -> Permissions -> "Allow executing as
# program," then try again. Either way, you can always run it by opening a
# terminal in this folder and typing: bash Start_Entihack_Linux.sh

cd "$(dirname "$0")"

echo "=================================================="
echo " Entihack — starting up (Linux)"
echo "=================================================="
echo ""
echo "Installing required packages (only needed the first time)..."
pip3 install -r requirements.txt --quiet --break-system-packages 2>/dev/null || pip3 install -r requirements.txt --quiet

echo "Setting up the local database..."
python3 storage.py

if [ ! -f api_key.txt ]; then
    cp api_key.txt.example api_key.txt
    echo ""
    echo "Created api_key.txt — open it in any text editor and type your own"
    echo "key on its own line to enable the Block button. Any text works."
fi

echo ""
echo "Starting the honeypot, tarpit, API, and dashboard..."
python3 honeypot.py > logs_honeypot.txt 2>&1 &
python3 tarpit.py > logs_tarpit.txt 2>&1 &
python3 api.py --port 5050 > logs_api.txt 2>&1 &
python3 dashboard.py > logs_dashboard.txt 2>&1 &

sleep 2
echo ""
echo "=================================================="
echo " Entihack is running."
echo " Dashboard:  http://localhost:5000"
echo " Live API:   http://localhost:5050"
echo "=================================================="
echo ""

if command -v xdg-open >/dev/null 2>&1; then
    echo "Opening the dashboard in your browser..."
    xdg-open "http://localhost:5000" >/dev/null 2>&1
else
    echo "Open http://localhost:5000 in your browser manually."
fi

echo ""
echo "Leave this window open while you want Entihack running."
echo "Use Stop_Entihack_Linux.sh to shut everything down later."
echo ""
read -p "Press Enter to close this window (this will NOT stop Entihack)... "
