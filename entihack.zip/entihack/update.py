"""
update.py — the "update like Apple updates your phone" feature: downloads
the latest Entihack code and applies it in-place, automatically preserving
everything a new version could never touch anyway (your data, your keys),
and automatically backing them up first as an extra safety net.

WHAT ACTUALLY HAPPENS (no magic, just automation of steps you could do
by hand — this just does them for you, in order, safely):
  1. Downloads the latest entihack.zip from the GitHub repo.
  2. Runs backup.py's create_backup() automatically first.
  3. Extracts the new zip INTO this same folder (never deletes anything
     first) — since data/entihack.db, exports/, and all key files are
     never inside any Entihack zip, they're never touched by this step.
  4. Reports exactly which files changed.

This is NOT "magic" and doesn't rewrite code in some clever/opaque way —
it's the same "extract a new zip into your existing folder" process
described in the README, just automated and backed up automatically so
you don't have to remember the steps or do them by hand.

USAGE:
    python3 update.py                 # checks, backs up, updates
    python3 update.py --check-only    # just reports if an update exists
"""

import os
import sys
import zipfile
import hashlib
import argparse
import urllib.request
import urllib.error

BASE_DIR = os.path.dirname(__file__)
# Overridable for local testing (e.g. against a local http.server) without
# touching the real GitHub repo — unset, these point at the real release.
ZIP_URL = os.environ.get(
    "ENTIHACK_UPDATE_ZIP_URL",
    "https://raw.githubusercontent.com/OshJ11872/EntiHack-Downloads-Check-the-READ-ME/main/entihack.zip",
)
VERSION_URL = os.environ.get(
    "ENTIHACK_UPDATE_VERSION_URL",
    "https://raw.githubusercontent.com/OshJ11872/EntiHack-Downloads-Check-the-READ-ME/main/VERSION",
)
TEMP_ZIP = os.path.join(BASE_DIR, "_update_download.zip")


def get_local_version():
    path = os.path.join(BASE_DIR, "VERSION")
    if os.path.exists(path):
        with open(path) as f:
            first_line = f.readline().strip()
            return first_line if first_line else "unknown"
    return "unknown"


def get_local_version_hash():
    """The second line of VERSION, if present, is the sha256 of update.py
    at release time — used by the viewer page to verify authenticity.
    Not used by this script itself, just kept here for reference/consistency."""
    path = os.path.join(BASE_DIR, "VERSION")
    if os.path.exists(path):
        with open(path) as f:
            lines = f.read().splitlines()
            if len(lines) >= 2:
                return lines[1].strip()
    return None


def get_remote_version():
    try:
        with urllib.request.urlopen(VERSION_URL, timeout=5) as resp:
            first_line = resp.read().decode().splitlines()[0].strip()
            return first_line
    except Exception:
        return None

# Never overwritten by an update — matches backup.py's list exactly, since
# these are also exactly what every Entihack zip already excludes.
NEVER_TOUCHED = {
    "data/entihack.db",
    "api_key.txt",
    "abuseipdb_key.txt",
}

# Files that were part of official Entihack releases but have since been
# deliberately removed. This is an EXPLICIT list, never auto-detected —
# a plain "extract the new zip over the old one" never deletes anything on
# its own, since zip extraction only overwrites files that exist in the new
# archive. Without this list, a removed file (like rubiscout.py) would
# silently survive every future upgrade forever. Add to this list any time
# a file is intentionally dropped from the project.
KNOWN_REMOVED_FILES = {
    "rubiscout.py",
    "rubiscout_key.txt.example",
}


def find_removable_files():
    """Which KNOWN_REMOVED_FILES actually exist locally right now."""
    return [f for f in KNOWN_REMOVED_FILES if os.path.exists(os.path.join(BASE_DIR, f))]


def remove_known_removed_files():
    removed = []
    for f in find_removable_files():
        try:
            os.remove(os.path.join(BASE_DIR, f))
            removed.append(f)
        except OSError:
            pass
    return removed


def _file_hash(path):
    if not os.path.exists(path):
        return None
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def download_latest():
    print(f"Downloading latest version from:\n  {ZIP_URL}")
    try:
        urllib.request.urlretrieve(ZIP_URL, TEMP_ZIP)
    except (urllib.error.URLError, Exception) as e:
        print(f"Download failed: {e}")
        print("Check your internet connection, or verify the URL still points "
              "to a real file at github.com/OshJ11872/EntiHack-Downloads-Check-the-READ-ME.")
        return None
    return TEMP_ZIP


def check_for_changes(new_zip_path):
    """Compares every file in the new zip against what's currently on disk.
    Returns (changed_files, new_files, unchanged_count)."""
    changed, new = [], []
    unchanged = 0
    with zipfile.ZipFile(new_zip_path) as zf:
        for info in zf.infolist():
            if info.is_dir():
                continue
            # zip entries are like "entihack/honeypot.py" — strip the leading folder
            rel_path = info.filename.split("/", 1)[-1] if "/" in info.filename else info.filename
            if rel_path in NEVER_TOUCHED or rel_path.startswith("data/") or rel_path.startswith("exports/"):
                continue
            local_path = os.path.join(BASE_DIR, rel_path)
            new_hash = hashlib.sha256(zf.read(info.filename)).hexdigest()
            old_hash = _file_hash(local_path)
            if old_hash is None:
                new.append(rel_path)
            elif old_hash != new_hash:
                changed.append(rel_path)
            else:
                unchanged += 1
    return changed, new, unchanged


def apply_update(new_zip_path):
    with zipfile.ZipFile(new_zip_path) as zf:
        for info in zf.infolist():
            if info.is_dir():
                continue
            rel_path = info.filename.split("/", 1)[-1] if "/" in info.filename else info.filename
            if rel_path in NEVER_TOUCHED or rel_path.startswith("data/") or rel_path.startswith("exports/"):
                continue  # never overwrite these, no matter what's in the zip
            target_path = os.path.join(BASE_DIR, rel_path)
            os.makedirs(os.path.dirname(target_path) or ".", exist_ok=True)
            with open(target_path, "wb") as f:
                f.write(zf.read(info.filename))


def main():
    parser = argparse.ArgumentParser(description="Update Entihack to the latest version")
    parser.add_argument("--check-only", action="store_true",
                         help="Only report whether an update is available, don't apply it")
    args = parser.parse_args()

    local_version = get_local_version()
    remote_version = get_remote_version()
    if remote_version:
        print(f"Local version: {local_version}  |  Latest on GitHub: {remote_version}")
    else:
        print(f"Local version: {local_version}  |  (couldn't check the latest version right now)")

    new_zip = download_latest()
    if not new_zip:
        sys.exit(1)

    changed, new, unchanged = check_for_changes(new_zip)
    to_remove = find_removable_files()

    if not changed and not new and not to_remove:
        print(f"Already up to date. ({unchanged} files checked, no differences.)")
        os.remove(new_zip)
        return

    print(f"\nUpdate available: {len(changed)} changed file(s), {len(new)} new file(s), "
          f"{len(to_remove)} file(s) to remove.")
    for f in changed:
        print(f"  changed: {f}")
    for f in new:
        print(f"  new:     {f}")
    for f in to_remove:
        print(f"  remove:  {f}  (dropped from the project — see the version's release notes)")

    if args.check_only:
        print("\n--check-only was set — nothing applied. Run without that flag to update.")
        os.remove(new_zip)
        return

    print("\nBacking up your data and keys first...")
    try:
        from backup import create_backup
        create_backup()
    except Exception as e:
        print(f"Warning: automatic backup failed ({e}). Continuing anyway, since your "
              f"data/keys were never going to be touched by this update regardless.")

    print("\nApplying update...")
    apply_update(new_zip)
    removed = remove_known_removed_files()
    os.remove(new_zip)

    print(f"\nDone. {len(changed) + len(new)} file(s) updated, {len(removed)} file(s) removed.")
    print("Your data/entihack.db, exports/, and key files were never touched.")


if __name__ == "__main__":
    main()
