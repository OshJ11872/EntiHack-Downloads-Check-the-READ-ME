"""
personas.py — V2 feature: makes the honeypot present as a DIFFERENT, but
internally CONSISTENT, fake system depending on which attacker is looking.

WHY THIS EXISTS:
A honeypot that always shows the exact same SSH banner and the exact same
fake login page is easy for a careful attacker to fingerprint — sophisticated
scanners and threat-intel feeds maintain databases of known honeypot
signatures (default Cowrie banners, default fake pages, etc.) and skip
anything that matches. Mismatched details are also a tell on their own: a
real Synology NAS doesn't run a stock Ubuntu OpenSSH banner next to a
WordPress login page. Each persona below pairs an SSH banner with a
matching HTTP page and matching fake filenames, so what an attacker sees is
internally coherent, not a random grab-bag.

HOW PERSONAS ARE ASSIGNED (see storage.py's ip_personas table):
- The SAME source IP always sees the SAME persona on every connection,
  looked up from storage rather than re-randomized each time. Switching
  identity mid-conversation with the same visitor would itself be a dead
  giveaway that something fake is going on.
- DIFFERENT source IPs may get DIFFERENT, randomly-chosen personas. This
  means the honeypot doesn't have one single fixed fingerprint that a
  shared threat-intel database could flag across many deployments.

WHAT THIS DOES NOT DO:
This changes application-layer content (banners, page HTML, fake
filenames) — it does NOT change TCP/IP-stack-level fingerprints (TTL,
window size, OS fingerprinting via tools like p0f or nmap -O), which would
require kernel-level changes outside what a Python socket server can do.
A sufficiently deep fingerprinting attempt could still tell this is running
on whatever OS Entihack itself is hosted on, regardless of which persona
is presented at the application layer. Documented honestly rather than
implying this defeats all forms of fingerprinting.
"""

import random

PERSONAS = {
    "linux-webserver": {
        "ssh_banner": "SSH-2.0-OpenSSH_8.9p1 Ubuntu-3ubuntu0.6",
        "http_title": "Admin Login",
        "http_body": (
            "<html><head><title>Admin Login</title></head><body>"
            "<h2>Server Admin Login</h2>"
            "<form method='POST'><input name='username' placeholder='Username'>"
            "<input name='password' type='password' placeholder='Password'>"
            "<button>Sign in</button></form></body></html>"
        ),
        "tarpit_dirs": ["backup", "var", "etc", "uploads", "logs"],
        "tarpit_files": ["shadow.bak", "id_rsa", ".env.save", "backup.tar.gz"],
    },
    "synology-nas": {
        "ssh_banner": "SSH-2.0-Synology_9.0",
        "http_title": "Synology DiskStation Manager",
        "http_body": (
            "<html><head><title>Synology DiskStation Manager</title></head><body>"
            "<h2>DiskStation Manager Login</h2>"
            "<form method='POST'><input name='username' placeholder='Username'>"
            "<input name='password' type='password' placeholder='Password'>"
            "<button>Log In</button></form></body></html>"
        ),
        "tarpit_dirs": ["volume1", "photo", "homes", "docker", "surveillance"],
        "tarpit_files": ["synoinfo.conf", "user_backup.tar", "diskstation.db"],
    },
    "router-admin": {
        "ssh_banner": "SSH-2.0-dropbear_2022.83",
        "http_title": "Router Configuration",
        "http_body": (
            "<html><head><title>Router Configuration</title></head><body>"
            "<h2>Wireless Router Login</h2>"
            "<form method='POST'><input name='username' placeholder='Admin ID'>"
            "<input name='password' type='password' placeholder='Password'>"
            "<button>Login</button></form></body></html>"
        ),
        "tarpit_dirs": ["firmware", "wan", "lan", "wireless", "qos"],
        "tarpit_files": ["config.bin", "firmware_update.img", "wps_pin.txt"],
    },
    "wordpress-cms": {
        "ssh_banner": "SSH-2.0-OpenSSH_7.4",
        "http_title": "Log In \u2039 WordPress",
        "http_body": (
            "<html><head><title>Log In &lsaquo; WordPress</title></head><body>"
            "<h2>WordPress Login</h2>"
            "<form method='POST'><input name='username' placeholder='Username or Email'>"
            "<input name='password' type='password' placeholder='Password'>"
            "<button>Log In</button></form></body></html>"
        ),
        "tarpit_dirs": ["wp-content", "wp-includes", "wp-admin", "uploads", "plugins"],
        "tarpit_files": ["wp-config.php.bak", "dump.sql", "debug.log"],
    },
    "jenkins-ci": {
        "ssh_banner": "SSH-2.0-OpenSSH_8.4p1 Debian-5",
        "http_title": "Sign in [Jenkins]",
        "http_body": (
            "<html><head><title>Sign in [Jenkins]</title></head><body>"
            "<h2>Jenkins Login</h2>"
            "<form method='POST'><input name='username' placeholder='Username'>"
            "<input name='password' type='password' placeholder='Password'>"
            "<button>Sign in</button></form></body></html>"
        ),
        "tarpit_dirs": ["jobs", "workspace", ".jenkins", "plugins", "secrets"],
        "tarpit_files": ["credentials.xml", "config.xml.bak", "build.log"],
    },
}

PERSONA_NAMES = list(PERSONAS.keys())


def random_persona_name():
    return random.choice(PERSONA_NAMES)


def get_persona(name):
    """Returns the persona dict, falling back to a default if the stored name is somehow unrecognized."""
    return PERSONAS.get(name, PERSONAS[PERSONA_NAMES[0]])
