#!/bin/bash
# Stop_Entihack_Linux.sh
# Double-click (or run via: bash Stop_Entihack_Linux.sh) to stop everything
# Start_Entihack_Linux.sh started.

cd "$(dirname "$0")"

echo "Stopping Entihack..."
pkill -f "honeypot\.py" 2>/dev/null
pkill -f "tarpit\.py" 2>/dev/null
pkill -f "api\.py" 2>/dev/null
pkill -f "dashboard\.py" 2>/dev/null

echo "Stopped. Any IPs that were blocked stay blocked (saved in data/entihack.db) —"
echo "run Start_Entihack_Linux.sh again any time to pick back up where you left off."
echo ""
read -p "Press Enter to close this window... "
