"""
ai_explainer.py — optional plain-language summary of a captured session,
using Claude via the Anthropic API.

This requires YOUR OWN Anthropic API key (get one at console.anthropic.com).
Set it as an environment variable before running:

    export ANTHROPIC_API_KEY=sk-ant-...

I'm deliberately not hardcoding a model name I can't verify is currently
correct/available — check https://docs.claude.com for the current model
identifiers and pricing before wiring this into anything you run at scale.
As of my knowledge, 'claude-sonnet-4-6' or a similarly named current Sonnet
model would be reasonable choices, but please confirm the exact string in
the docs rather than trusting this comment.

Requires: pip install anthropic --break-system-packages
"""

import os
import json

SYSTEM_PROMPT = """You are analyzing a single logged connection to a defensive honeypot.
Explain, in 3-5 plain-language sentences, what the visitor appears to have done
and what each piece of captured data suggests. Be calibrated: if the data is
too thin to tell much, say so plainly rather than inventing detail. Do not
speculate about the person's identity. Do not provide any instructions for
retaliating against, exploiting, or accessing the source IP — only describe
what was observed."""


def explain_session(session: dict) -> str:
    try:
        import anthropic
    except ImportError:
        return "anthropic package not installed — run: pip install anthropic --break-system-packages"

    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        return "No ANTHROPIC_API_KEY set in environment — see ai_explainer.py docstring."

    client = anthropic.Anthropic(api_key=api_key)

    payload = {
        "service": session.get("service"),
        "path_or_target": session.get("path_or_target"),
        "raw_data": session.get("raw_data"),
        "credentials_tried": session.get("credentials_tried"),
        "profile_label": session.get("profile_label"),
        "profile_confidence": session.get("profile_confidence"),
        "geo": session.get("geo_json"),
    }

    try:
        # NOTE: verify current model name/params against docs.claude.com before relying on this.
        response = client.messages.create(
            model="claude-sonnet-4-6",
            max_tokens=300,
            system=SYSTEM_PROMPT,
            messages=[{"role": "user", "content": json.dumps(payload, indent=2)}],
        )
        return "".join(block.text for block in response.content if hasattr(block, "text"))
    except Exception as e:
        return f"AI summary failed: {e}"


if __name__ == "__main__":
    from storage import get_session
    import sys
    sid = int(sys.argv[1]) if len(sys.argv) > 1 else 1
    s = get_session(sid)
    if not s:
        print("No such session.")
    else:
        print(explain_session(s))
