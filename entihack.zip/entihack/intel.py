"""
intel.py — IP geolocation / WHOIS lookups.

Notes on accuracy (read before relying on this):
- IP geolocation is approximate. It typically identifies the ISP/hosting
  provider and a city/region, NOT a precise physical address, and is
  frequently wrong for VPNs, proxies, Tor exit nodes, or cloud hosting IPs
  (which is exactly what most attacking IPs are). Treat it as a lead, not
  a location.
- This uses ip-api.com's free JSON endpoint (http://ip-api.com/json/<ip>),
  which does not require an API key. I have not been able to test this
  network call myself in this sandboxed environment (outbound network here
  is restricted to a small allowlist of package/dev domains). Please verify
  it works and check ip-api.com's current rate limits/terms before relying
  on it for anything beyond casual/personal use.
- WHOIS lookups use the `ipwhois` Python package. Verify it's still current
  on PyPI (`pip show ipwhois`) — I'm not certifying its exact current API
  surface, only that this is the standard library used for this purpose.
- The "worldwide count" feature uses AbuseIPDB (https://www.abuseipdb.com),
  a real, established service that aggregates abuse reports submitted by
  system administrators worldwide — it's the same database used by
  fail2ban, UFW, and Cloudflare WAF integrations. It requires your own free
  API key (register at abuseipdb.com, free tier allows 1,000 checks/day).
  Without a key, this feature is simply skipped — nothing is fabricated in
  its place.
"""

import json
import os
import urllib.request
import urllib.parse
import urllib.error


def geolocate_ip(ip: str, timeout=5) -> dict:
    """Best-effort geolocation. Returns a dict with an 'error' key on failure."""
    url = f"http://ip-api.com/json/{ip}?fields=status,message,country,regionName,city,isp,org,as,proxy,hosting,query"
    try:
        with urllib.request.urlopen(url, timeout=timeout) as resp:
            data = json.loads(resp.read().decode())
            if data.get("status") != "success":
                return {"error": data.get("message", "lookup failed"), "ip": ip}
            return data
    except (urllib.error.URLError, TimeoutError, Exception) as e:
        return {"error": str(e), "ip": ip}


def whois_lookup(ip: str) -> dict:
    """
    Best-effort WHOIS lookup using the `ipwhois` package.
    Falls back gracefully with an explicit error if the package isn't installed
    or the lookup fails — never silently fabricates data.
    """
    try:
        from ipwhois import IPWhois  # pip install ipwhois
    except ImportError:
        return {"error": "ipwhois package not installed — run: pip install ipwhois --break-system-packages"}

    try:
        obj = IPWhois(ip)
        result = obj.lookup_rdap(depth=1)
        return {
            "asn": result.get("asn"),
            "asn_description": result.get("asn_description"),
            "network_name": (result.get("network") or {}).get("name"),
            "country": result.get("asn_country_code"),
        }
    except Exception as e:
        return {"error": str(e)}


def load_abuseipdb_key(key_file_path=None):
    """
    Same pattern as api.py's key loading: env var first, then a local text
    file, comment lines (#) ignored. Returns None if neither is set —
    AbuseIPDB lookups are simply skipped in that case.
    """
    env_key = os.environ.get("ABUSEIPDB_API_KEY")
    if env_key:
        return env_key.strip()

    path = key_file_path or os.path.join(os.path.dirname(__file__), "abuseipdb_key.txt")
    if os.path.exists(path):
        with open(path) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#"):
                    return line
    return None


def abuseipdb_check(ip: str, api_key=None, timeout=5) -> dict:
    """
    Checks an IP against AbuseIPDB's real, worldwide-aggregated abuse report
    database. Returns the IP's total report count and confidence score if a
    key is configured and the lookup succeeds; otherwise returns a dict with
    an explicit 'error' or 'skipped' key — this never fabricates a number.

    Real endpoint (verified against AbuseIPDB's own docs):
      GET https://api.abuseipdb.com/api/v2/check
      Headers: Key: <your key>, Accept: application/json
      Params: ipAddress=<ip>, maxAgeInDays=90
    """
    key = api_key or load_abuseipdb_key()
    if not key:
        return {"skipped": "No AbuseIPDB API key configured (set ABUSEIPDB_API_KEY or abuseipdb_key.txt)."}

    url = "https://api.abuseipdb.com/api/v2/check"
    query = urllib.parse.urlencode({"ipAddress": ip, "maxAgeInDays": 90})
    req = urllib.request.Request(
        f"{url}?{query}",
        headers={"Key": key, "Accept": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            payload = json.loads(resp.read().decode())
            data = payload.get("data", {})
            return {
                "total_reports": data.get("totalReports"),
                "abuse_confidence_score": data.get("abuseConfidenceScore"),
                "num_distinct_reporters": data.get("numDistinctUsers"),
                "country_code": data.get("countryCode"),
                "is_public": data.get("isPublic"),
                "last_reported_at": data.get("lastReportedAt"),
            }
    except (urllib.error.URLError, TimeoutError, Exception) as e:
        return {"error": str(e)}


def full_lookup(ip: str) -> dict:
    """Combines geolocation + WHOIS + AbuseIPDB worldwide report count into one dict."""
    return {
        "geo": geolocate_ip(ip),
        "whois": whois_lookup(ip),
        "abuseipdb": abuseipdb_check(ip),
    }


if __name__ == "__main__":
    import sys
    target = sys.argv[1] if len(sys.argv) > 1 else "8.8.8.8"
    print(json.dumps(full_lookup(target), indent=2))
