#!/bin/bash
# Start_Entihack.command
#
# Double-click this file to install everything Entihack needs and start it —
# no typing in a terminal required. (On Mac, a Terminal window will open by
# itself to show progress/logs — that's normal, you just don't need to type
# anything into it.)
#
# First time on Mac: right-click this file -> Open, then confirm "Open"
# in the security prompt (macOS blocks double-clicking downloaded scripts
# the very first time as a safety measure — this is normal for any
# downloaded .command file, not specific to Entihack).

cd "$(dirname "$0")"

echo "=================================================="
echo " Entihack — starting up"
echo "=================================================="
echo ""
echo "Installing required packages (only needed the first time)..."
pip3 install -r requirements.txt --quiet --break-system-packages 2>/dev/null || pip3 install -r requirements.txt --quiet

echo "Setting up the local database..."
python3 storage.py

# If the key file doesn't exist yet, create it from the template so there's
# always a text file waiting for you to fill in — no terminal needed for that.
if [ ! -f api_key.txt ]; then
    cp api_key.txt.example api_key.txt
    echo ""
    echo "Created api_key.txt — open it in any text editor and type your own"
    echo "key on its own line to enable the Block button. Any text works, no"
    echo "special format required. You can also skip this for now; everything"
    echo "except live blocking will still work."
fi

echo ""
echo "Starting the honeypot, tarpit, API, and dashboard..."
python3 honeypot.py > logs_honeypot.txt 2>&1 &
python3 tarpit.py > logs_tarpit.txt 2>&1 &
python3 api.py --port 5050 > logs_api.txt 2>&1 &
python3 dashboard.py > logs_dashboard.txt 2>&1 &

sleep 2
echo ""
echo "=================================================="
echo " Entihack is running."
echo " Dashboard:  http://localhost:5000"
echo " Live API:   http://localhost:5050"
echo "=================================================="
echo ""
echo "Opening the dashboard in your browser..."

# Open the dashboard automatically (works on Mac; on Linux, opens if
# xdg-open is available — otherwise just visit the URL above manually).
if command -v open >/dev/null 2>&1; then
    open "http://localhost:5000"
elif command -v xdg-open >/dev/null 2>&1; then
    xdg-open "http://localhost:5000"
fi

echo "You can close this window's programs later with Stop_Entihack.command."
echo "Leave this window open while you want Entihack running."
echo ""
read -p "Press Enter to close this window (this will NOT stop Entihack — use Stop_Entihack.command for that)... "
