@echo off
REM Stop_Entihack.bat
REM Double-click this to stop everything Start_Entihack.bat started.

echo Stopping Entihack...
taskkill /F /FI "WINDOWTITLE eq Entihack*" >nul 2>&1

echo Stopped. Any IPs that were blocked stay blocked (saved in data\entihack.db) -
echo run Start_Entihack.bat again any time to pick back up where you left off.
echo.
pause
