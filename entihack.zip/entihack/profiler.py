"""
profiler.py — heuristic (NOT definitive) attacker profiling.

IMPORTANT HONESTY NOTE:
This produces a best-guess label based on simple pattern matching against
what was probed/attempted. It is not forensic proof of intent, skill level,
or identity, and should always be presented to the user as a heuristic
estimate, not a fact. False positives and false negatives are both common
with this kind of rule-based approach — treat it as a triage aid, not a verdict.
"""

from dataclasses import dataclass

# Each rule: (label, confidence, matcher_function)
# matcher receives a dict with keys: service, path_or_target, raw_data, credentials_tried (list)

def _lower(s):
    return (s or "").lower()


RULES = []


def rule(label, confidence):
    def decorator(fn):
        RULES.append((label, confidence, fn))
        return fn
    return decorator


@rule("IoT/router credential stuffing", "medium")
def _iot_creds(ev):
    creds = ev.get("credentials_tried") or []
    common_iot = {"admin:admin", "root:root", "admin:1234", "root:12345", "admin:password"}
    for c in creds:
        pair = f"{_lower(c.get('user',''))}:{c.get('pass','')}"
        if pair in common_iot:
            return True
    return False


@rule("CMS / web app exploitation attempt (e.g. WordPress, phpMyAdmin)", "medium")
def _cms_scan(ev):
    target = _lower(ev.get("path_or_target"))
    return any(x in target for x in ["wp-admin", "wp-login", "phpmyadmin", "xmlrpc.php", "/.env"])


@rule("Financial-system targeting (heuristic only — path/keyword based)", "low")
def _fin_target(ev):
    target = _lower(ev.get("path_or_target")) + " " + _lower(ev.get("raw_data"))
    return any(x in target for x in ["swift", "wire-transfer", "core-banking", "/bank", "iban"])


@rule("Automated vulnerability scanner (generic)", "medium")
def _generic_scanner(ev):
    raw = _lower(ev.get("raw_data"))
    ua_markers = ["nmap", "masscan", "zgrab", "sqlmap", "nikto", "python-requests"]
    return any(m in raw for m in ua_markers)


@rule("SSH brute-force attempt", "medium")
def _ssh_brute(ev):
    return ev.get("service") == "fake-ssh" and len(ev.get("credentials_tried") or []) >= 1


def compute_threat_level(profile_confidence, strikes=0, blocked=False):
    """
    Combines the heuristic profile confidence with how many times this IP has
    struck to produce a single simple threat_level: 'low' | 'medium' | 'high'.
    This is still a heuristic, not a certainty — surfaced as such in the UI.
    """
    if blocked:
        return "high"
    if profile_confidence == "high" or strikes >= 3:
        return "high"
    if profile_confidence == "medium" or strikes >= 1:
        return "medium"
    return "low"


def profile_event(event: dict):
    """
    Returns (label, confidence) — always heuristic.
    If nothing matches, returns an explicit 'unclassified' result rather than
    guessing, per the principle of not overstating certainty.
    """
    for label, confidence, matcher in RULES:
        try:
            if matcher(event):
                return label, confidence
        except Exception:
            continue
    return "Unclassified — insufficient pattern match (heuristic engine, not a definitive ID)", "low"
