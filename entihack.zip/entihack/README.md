# Entihack (prototype)

> **If you're on the original v1 build (no `update.py` in your folder), it's no longer supported** — it included a feature that's since been removed. You can still use it as-is, but a one-time manual upgrade is strongly recommended. See "Updating to a new version without losing your data" below.

A local defensive-security toolkit: honeypot capture + heuristic attacker
profiling + IP intel + a deception "maze" (tarpit) + a dashboard, with an
optional AI plain-language summary of each captured session.

## Easiest way to run this (no terminal typing required)

- **Mac:** double-click `Start_Entihack.command`.
  *(First time only: macOS blocks newly-downloaded scripts from running by
  double-click — if nothing happens, right-click the file, choose "Open,"
  then confirm "Open" in the popup. After that, double-clicking works normally.)*
- **Windows:** double-click `Start_Entihack.bat`.
  *(Requires Python installed from [python.org](https://python.org) first —
  a one-time install like any other program. If double-clicking does
  nothing, that's what's missing.)*
- **Linux:** double-click `Start_Entihack_Linux.sh` and choose "Run" or "Run
  in Terminal" if your file manager asks (Nautilus, Files, Dolphin, etc. all
  support this). If double-clicking just opens it as a text file instead,
  right-click it → Properties → Permissions → enable "Allow executing file
  as program," then try again. Always works as a fallback: open a terminal
  in this folder and run `bash Start_Entihack_Linux.sh`.
- **Chromebook (ChromeOS):** turn on Linux first — Settings → Advanced →
  Developer → "Linux development environment" (one-time setup, this gives
  you a real Linux container). Then copy this folder into the "Linux files"
  location in the Files app, open the Terminal app that Linux setup added,
  `cd` into the folder, and run `bash Start_Entihack_Linux.sh`. ChromeOS
  doesn't support double-click-to-run scripts the way Mac/Windows/Linux
  desktops do, so the terminal command is the reliable path here.

Either one installs what's needed, starts everything (honeypot, tarpit,
live API, dashboard), and opens the dashboard in your browser
automatically. A terminal/command window will pop up to show progress —
you don't need to type anything into it, just leave it open while you want
Entihack running. To stop everything, double-click `Stop_Entihack.command`
(Mac), `Stop_Entihack.bat` (Windows), or `Stop_Entihack_Linux.sh`
(Linux/Chromebook).

**Setting your API key without a terminal:** the launcher creates
`api_key.txt` for you automatically from the template. Just open it in any
plain text editor (Notepad, TextEdit, gedit — not Word), type your key on
its own line below the `#PUT YOUR KEY HERE` comment, and save. **The key
can be literally any text you want** — there's no required format, length,
or character set. It's just compared as plain text, so "my-dog-fido-2026"
is exactly as valid as a long random string (though a longer, harder-to-guess
one is safer if this will ever be reachable from outside your own machine).

Everything below this section is the manual/terminal-based version of the
same steps.

## Updating to a new version without losing your data

**Swapping in a new `entihack_viewer.html` alone is always safe** — it's a
standalone file with no connection to your captured data or keys. Replace
it any time with zero risk.

**Extracting a new full zip is also safe, as long as you extract it INTO
your existing folder** (not delete-and-replace). Every Entihack zip
deliberately excludes `data/entihack.db`, `exports/`, `api_key.txt`,
and `abuseipdb_key.txt` — they're simply not in the
zip, so there's nothing for the new version to overwrite them with.

**The one real risk** is deleting your whole `entihack` folder before
extracting a new version — that takes your captured data and keys down
with it, since nothing else has a copy. `backup.py` exists for exactly
this:

```bash
python3 backup.py create              # makes a timestamped backup .zip in backups/
```
If something goes wrong:
```bash
python3 backup.py restore backups/entihack_backup_<timestamp>.zip
```
Tested by actually deleting the database, both key files, and an export,
then confirming restore brought back the identical database, both keys
with correct content, and the export file.

**One security note:** a backup file contains your API keys in plain
text if you've set any — treat backup `.zip` files like a password file,
not something to casually share or commit to a public repo.

## Updating automatically ("update.py")

This automates the process above — check for changes, back up first,
apply the update, leave your data/keys untouched:

```bash
python3 update.py --check-only    # see what would change, without applying it
python3 update.py                 # backs up, then downloads + applies the update
```

Tested for real: edited a file locally, confirmed `--check-only` correctly
flagged it as different from the version on GitHub, then ran the real
update and confirmed the edited file got correctly overwritten with the
current GitHub version — while a real API key and a real database sitting
in the same folder came through completely untouched, and a backup was
created automatically first.

This isn't magic — it downloads the current `entihack.zip` from the GitHub
repo and extracts it into your existing folder, exactly like the manual
process above, just automated and backed up for you.

## Pre-flight diagnostics ("diagnostics.py")

Runs a real health check before starting anything — Python version,
required packages, folder write access, whether the honeypot/tarpit/API/
dashboard ports are already taken, whether the database and persona system
load cleanly, and whether an API key is configured:

```bash
python3 diagnostics.py
```

Wired into all three launchers (`Start_Entihack.command`, `.bat`, and
`_Linux.sh`) — it runs automatically before the servers start, and stops
you with a clear message if something critical is actually wrong (missing
Flask, no write access, a broken database) rather than letting you start
into a silent failure.

Every check here is real — tested by actually occupying a port and
confirming it's correctly flagged as "already in use," and by confirming a
genuinely healthy system reports all-clear. Missing optional packages
(like `ipwhois` or `anthropic`) are flagged but don't block startup, since
the rest of Entihack already degrades gracefully without them.

**Optional AI summary:** if `ANTHROPIC_API_KEY` is set (same pattern as
`ai_explainer.py`), the results get sent to Claude for a short plain-English
summary at the end. This reuses the same general-purpose model already
used elsewhere in the project — it is not a custom-trained model, just an
existing AI reading this specific output. Skipped entirely if no key is set.

## Running this on Google Cloud Platform (GCP) instead of your own machine

If you want Entihack (specifically `api.py`, for live/remote access) running
on a server you don't have to keep your own computer on for:

1. Create a free-tier-eligible VM: **Compute Engine → Create Instance** —
   an `e2-micro` instance qualifies for GCP's always-free tier in certain
   regions (verify current free-tier terms at
   [cloud.google.com/free](https://cloud.google.com/free), since these
   terms can change). Choose a Debian or Ubuntu image.
2. Open the firewall for the ports you need: **VPC network → Firewall →
   Create firewall rule** — allow TCP on 5050 (the API), and optionally
   2222/8080/8888 if you want the honeypot itself reachable from the
   public internet rather than just locally.
3. SSH into the instance (GCP gives you a browser-based SSH button, no
   separate SSH client needed), then:
   ```bash
   git clone <wherever you host this project>   # or upload the zip via the
                                                  # SSH-in-browser file upload
   cd entihack
   bash Start_Entihack_Linux.sh
   ```
4. Use the VM's external IP (shown on the Compute Engine instance list) as
   the `LIVE_URL` in `entihack_viewer.html`'s "Connect to a live server" tab
   — e.g. `http://<external-ip>:5050`.

**Before doing this for real, revisit the security notes earlier in this
README** — running `api.py` reachable from the public internet means the
HTTPS and rate-limiting gaps mentioned there actually matter, not just in
theory. A GCP VM is a real public-facing server the moment its firewall is
opened, same as any other cloud host.

## Manual setup (terminal-based)

## What this actually is, honestly

This is a **passive** capture and deception toolkit, not an offensive tool.
It listens, logs, and (in the tarpit) wastes an automated scanner's time with
fake pages. It never sends anything to an attacker's machine beyond a generic
fake banner/page, never executes anything on their system, and never "hacks
back." That's a deliberate design boundary, not an oversight — actively
attacking or sending commands to someone else's machine, even someone
attacking you, is unauthorized computer access in essentially every
jurisdiction (e.g. the CFAA in the US), regardless of their conduct.

## Components

| File | What it does |
|---|---|
| `storage.py` | SQLite storage shared by everything |
| `honeypot.py` | Fake SSH banner + fake HTTP login page; logs every connection |
| `tarpit.py` | Flask app serving an endless fake directory maze, deliberately slow |
| `profiler.py` | Rule-based heuristic labeling (e.g. "SSH brute-force attempt") — always a guess, never a verdict |
| `intel.py` | IP geolocation (ip-api.com) + WHOIS (ipwhois) lookups |
| `dashboard.py` | Web UI at http://localhost:5000 to browse captures + the blocklist |
| `ai_explainer.py` | Optional: calls the Anthropic API to summarize a session in plain English |
| `blocker.py` | Auto-blocks repeat offenders — refuses their connections, never contacts them |
| `export.py` | Exports every captured attack + the blocklist into a portable JSON/CSV report file |
| `backup.py` | Backs up (and restores) your data/keys before updating to a new version |
| `update.py` | Downloads the latest version and applies it in-place, automatically backed up, data/keys untouched |
| `diagnostics.py` | Pre-flight health check, runs automatically before the launchers start anything |
| `entihack_viewer.html` | Standalone app — file-upload mode, or live mode with a real Block button |
| `api.py` | The real backend for live mode: JSON API + authenticated block/unblock endpoints |
| `Start_Entihack.command` / `Start_Entihack.bat` | Double-click launchers (Mac / Windows) — no terminal typing needed |
| `Start_Entihack_Linux.sh` / `Stop_Entihack_Linux.sh` | Linux and ChromeOS (via Linux container) launcher/stopper |
| `Stop_Entihack.command` / `Stop_Entihack.bat` | Double-click to stop everything the launcher started |
| `api_key.txt.example` | Template for your API key — copy to `api_key.txt` and fill in any text you want |
| `abuseipdb_key.txt.example` | Template for your optional AbuseIPDB key — enables the worldwide report count |
| `README_GITHUB.md` | Trimmed copy of this README for publishing to a public repo |

## Setup

```bash
cd entihack
pip install -r requirements.txt --break-system-packages
python3 storage.py            # creates data/entihack.db
```

## Running it

Open three terminals:

```bash
python3 honeypot.py --ssh-port 2222 --http-port 8080
python3 tarpit.py --port 8888
python3 dashboard.py          # then visit http://localhost:5000
```

Test it against yourself first:
```bash
curl http://localhost:8080/
curl http://localhost:8888/wp-admin
```
You should see entries appear on the dashboard within a few seconds.

For the AI summary feature:
```bash
export ANTHROPIC_API_KEY=sk-ant-...
python3 ai_explainer.py 1      # summarizes session id 1
```

## Live mode — threat level, IP, and a real Block button

`entihack_viewer.html` has two tabs: **Load an export file** (the JSON
snapshot workflow above) and **Connect to a live server**, which talks
directly to `api.py` over HTTP and updates every 5 seconds.

Start the API on the machine running your honeypot (it reads the same
`data/entihack.db`):

```bash
export ENTIHACK_API_KEY="something-long-and-random"   # required to allow blocking
python3 api.py --port 5050 --allow-origin "https://your-viewer-site.example"
```

**Or, instead of the environment variable, save the key in a text file:**
```bash
cp api_key.txt.example api_key.txt
```
`api_key.txt.example` ships with just:
```
#PUT YOUR KEY HERE
```
Open `api_key.txt` and replace that line (or add a line below it) with your
actual key, e.g.:
```
#PUT YOUR KEY HERE
a1b2c3-your-own-random-string
```
Lines starting with `#` are ignored, so leaving the placeholder comment in
place is harmless — the server reads the first real line as the key. If you
never fill it in, the server starts fine but block/unblock stays disabled
(same as having no key at all) until you do.

`api.py` checks `ENTIHACK_API_KEY` first; if that's not set, it reads
`api_key.txt` next. This means you don't have to re-`export` it every time
you restart the server — it persists as a file. `.gitignore` already
excludes the real `api_key.txt` and `data/entihack.db` (but NOT the
`.example` file) so you don't accidentally commit your actual secret or
capture data if you put this project in version control.

Then in the viewer, click **Connect to a live server**, enter
`http://<that machine's address>:5050`, paste the API key, and hit Connect.
You'll see live rows with a computed **threat level** (low/medium/high —
derived from the profiler's confidence plus strike count) and a **Block
now** button per row. Clicking it calls `POST /api/block` on your server,
which runs the exact same `blocker.py` logic already described above — it
refuses that IP's connections from then on, and never contacts them.

Why this needs a real backend, not just static hosting: blocking an IP
means running code with access to your firewall/app state. A page hosted
on Netlify or GitHub Pages has no server behind it, so it literally cannot
do this by itself — `api.py` is that server. You can run it on the same
machine as the honeypot, or any VPS/box you control; just make sure the
viewer page can reach it (correct URL, and `--allow-origin` set to wherever
you're hosting the HTML).

**Security note:** the API key gates every block/unblock call — without
it, `POST /api/block` returns 401. Don't publish your key anywhere public,
and set `--allow-origin` to your actual site rather than leaving it at `*`
once this is running somewhere real; otherwise any website could ask your
server to block arbitrary IPs on your behalf.

## Documenting and viewing attacks (export + viewer)

```bash
python3 export.py                 # writes exports/entihack_report_<timestamp>.json (+ .csv)
```

Each entry in the report documents one captured attack: source IP,
timestamp, which fake service was hit, what path/target was probed,
credentials tried (if any), the heuristic "what we think they were
attacking" label, location estimate, and whether that IP got blocked.

To view it: open `entihack_viewer.html` directly in any browser (double-click
it, no server needed) and drag the exported `.json` file onto it, or click to
choose it. It's a self-contained local page — the file never leaves your
machine, nothing is uploaded to anything. It gives you a searchable table of
every attack plus a detail view per IP.

If you actually want this pushed to a real external app/dashboard (your own
server, a SIEM, a specific service), tell me which one and I'll build that
specific integration — I didn't pick a destination on your behalf since that
means choosing an auth method and a place your data goes.

## "Stop the hacker" (auto-blocking — multi-tier, rate-based)

Blocking is based on **speed of repeat attempts, checked against a table of
windows from 10 seconds up to 24 hours** — because attackers don't all move
at the same pace, and any single threshold misses either the very fast or
the very slow ones. The table (`TIERS` at the top of `blocker.py`) is
checked shortest-window-first; an IP is blocked the moment ANY tier trips:

| Window | Threshold | Implied rate | Catches |
|---|---|---|---|
| 10 seconds | 3 events | ~1080/hr | Obvious automated bursts |
| 30 seconds | 4 events | ~480/hr | Slightly throttled bots |
| 1 minute | 5 events | ~300/hr | |
| 2 minutes | 6 events | ~180/hr | |
| 5 minutes | 8 events | ~96/hr | |
| 1 hour | 12 events | ~12/hr | Persistent moderate-pace probing |
| 5 hours | 20 events | ~4/hr | |
| 12 hours | 25 events | ~2/hr | Deliberately-paced, slow evasion scanning |
| 24 hours | 40 events | ~1.7/hr | Very slow, multi-day-style evasion attempts |

The threshold rises with window size, but the **implied rate falls** —
that's the actual design principle: a burst is far more suspicious than
the same count spread across hours, so short windows stay strict and long
windows stay lenient per-unit-time. This lets it catch slow, deliberately-
paced scanning without flagging someone who just visits normally over a day.

Add, remove, or retune any row by editing the `TIERS` list directly —
it's just a list of `(window_seconds, threshold, label)` tuples.

Tested behavior (each using simulated timestamps to avoid literally waiting
hours):
- 3 attempts spaced 12 seconds apart → **not blocked** by the 10s tier.
- 3 attempts fired back-to-back → **blocked immediately** by the 10s tier.
- 6 attempts ~20 seconds apart over ~100 seconds → **blocked** by the
  2-minute tier (too slow for 10s/30s/1min, but crosses the 2min threshold).
- 4 attempts, ~30 seconds apart → **not blocked** by any tier.
- 12 attempts spread across ~50 minutes (none within 5 minutes of each
  other) → **blocked** by the 1-hour tier.
- 25 attempts spread across ~11 hours → **blocked** by the 12-hour tier.
- 40 attempts spread across ~22 hours (thin enough to not trip the 12-hour
  tier) → **blocked** by the 24-hour tier.
- 8 attempts spread across 10 hours (light, non-automated-looking usage)
  → **not blocked** by any tier.
- 10 attempts spread across 20 hours (still light/spaced usage) →
  **not blocked** by any tier, including the new 24-hour one.

Once blocked, Entihack refuses all further connections from that IP:

## Worldwide report count (AbuseIPDB) vs. this installation's own totals

Two different things, worth keeping straight:

- **Per-IP worldwide reports (AbuseIPDB):** how many *other* systems around
  the world have reported a specific IP address before — real data from
  [AbuseIPDB](https://www.abuseipdb.com), a community-run database (the
  same one used by fail2ban, UFW, and Cloudflare WAF integrations).
- **This installation's totals (`/api/stats`):** how many attacks and
  blocks *this specific Entihack install* has seen — real, but local-only,
  and deliberately labeled that way in the UI ("this installation only, not
  worldwide"). There's no live, cross-installation "total hackers blocked
  by everyone running Entihack" number — that would require a separate
  shared server that every installation reports into, which nothing here
  currently does. If you want that built, it's possible (a small shared
  stats server + each installation optionally pinging it with just a
  counter increment, no IP data), but it needs somewhere public to actually
  run — say the word if you want that built out.

```bash
cp abuseipdb_key.txt.example abuseipdb_key.txt
```
Register a free account at abuseipdb.com (free tier: 1,000 checks/day), get
your key from the API Settings tab, and add it to `abuseipdb_key.txt` below
the placeholder comment — same pattern as `api_key.txt`. Without a key, this
feature is simply skipped everywhere (dashboard, live viewer, exports) and
clearly says so — it never shows a fabricated or guessed number.

Where it shows up: the dashboard's "Worldwide reports" column, the live
viewer's "Worldwide" column and detail drawer, and in `export.py`'s JSON
report under `worldwide_reports`. The local-only totals show up as the stat
tiles at the top of the live viewer when connected.

- **App-level (always on):** honeypot.py and tarpit.py check the blocklist
  before doing anything else. A blocked IP gets nothing back — connection
  closed immediately, no banner, no fake page, no delay. This needs no
  special privileges and works everywhere.
- **OS-level (optional, `--enable-os-block`, Linux + root):** also adds an
  `iptables -A INPUT -s <ip> -j DROP` rule, so their packets get refused at
  the kernel level before even reaching this app — the same mechanism tools
  like fail2ban use.

This never sends anything to the source IP. It only changes how *your own*
server responds to *their* inbound traffic — the same as closing a door,
not the same as reaching through it. That distinction is what keeps this on
the legal side of "stop them" vs. "attack them."

Manage it directly:
```bash
python3 blocker.py list
python3 blocker.py block 1.2.3.4 --os-level
python3 blocker.py unblock 1.2.3.4
```

## Things I could not verify or build as originally described, and why

- **Community threat-sharing** — not built. If you want this, the honest
  path is reporting to a real, established feed like AbuseIPDB's API
  (requires their API key) rather than a bespoke "send to community" system,
  which would need its own moderation/abuse-prevention infrastructure to be
  safe and legal to run.
- **"AI that writes commands that change based on the hacker"** — not built,
  on purpose. Any interpretation of this that sends commands to or executes
  code on the attacker's machine is unauthorized access and illegal. What
  *is* built instead is the tarpit, which changes its fake content based on
  what's being probed, without ever touching the attacker's system.
- **IP geolocation precision** — I have not been able to test the ip-api.com
  call in my sandbox (network access here is restricted). It's a real,
  widely used free service, but verify it still works and check its rate
  limits/terms before relying on it. Geolocation from IP is approximate at
  best and frequently wrong for VPN/proxy/hosting traffic — which is most
  attack traffic.
- **SSH credential capture** — the fake-SSH listener in `honeypot.py` is a
  raw socket, not a real SSH server, so it can fingerprint connection
  attempts but cannot actually decrypt/capture real SSH login credentials.
  A genuine SSH honeypot capable of that (e.g. via `paramiko` implementing
  a real (fake) SSH server) is a larger build — say the word if you want
  that upgraded.

## Legal notes (not legal advice — verify for your situation)

- Running this on infrastructure you own/control and logging incoming
  connections is standard, legal defensive practice in the US and most
  jurisdictions.
- If you expose this to the public internet, you're logging real people's
  IP addresses, which may count as personal data under laws like GDPR if
  any EU-connected traffic hits it — check applicable data-protection
  obligations (retention limits, disclosure, etc.) before running this
  somewhere with real traffic at scale.

## License

This project is licensed under the **Creative Commons Attribution-NonCommercial 4.0 International (CC BY-NC 4.0)** License.

### 🟢 You are free to:
* **Share** — Copy and redistribute the material in any medium or format.
* **Adapt** — Remix, transform, and build upon the material.

### 🔴 Under the following terms:
* **Attribution** — You must give appropriate credit, provide a link to the license, and indicate if changes were made.
* **Non-Commercial** — You may not use the material for commercial purposes.

See the full [LICENSE](LICENSE) file for details.

You should credit this like this:
"This project uses code from [Your Name/Username]'s [Repository Name], which is licensed under CC BY-NC 4.0."
