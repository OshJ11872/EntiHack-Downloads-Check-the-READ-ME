"""
blocker.py — the "stop the hacker, don't attack them" module.

WHAT "STOP" MEANS HERE (and what it deliberately does NOT mean):
- It means: after an IP crosses a strike threshold, Entihack refuses to
  accept any further connections from it — either at the application level
  (always available, no special privileges needed) or, optionally, at the
  OS firewall level via iptables (Linux, requires root).
- It never means: sending any packet, request, exploit, or command TO the
  attacker's IP. This module makes zero outbound connections to the source
  IP. It only changes how *your own* server responds to *their* inbound
  connections — which is the same thing as closing a door, not throwing a
  punch. That's what keeps this legal: you're only ever exercising control
  over your own systems.

TWO LAYERS:
1. App-level block (default, always on): honeypot.py / tarpit.py check
   `storage.is_blocked(ip)` before doing anything else. If blocked, they
   just close the connection immediately with no response at all — not
   even the fake banner/page.
2. OS-level block (optional, `--enable-os-block`, needs root, Linux only):
   also runs `iptables -A INPUT -s <ip> -j DROP`, so the traffic is refused
   at the kernel/firewall level before it even reaches this app. This is the
   same mechanism tools like fail2ban use.

STRIKE LOGIC — MULTI-TIER, checked from shortest window to longest:
An IP is checked against a table of (window, threshold) pairs — TIERS
below, from 10 seconds up to 12 hours. Unlike a flat threshold, each row
uses a DIFFERENT threshold: the count rises with window size, but the
implied per-hour RATE falls, so short windows stay strict and long windows
stay lenient per-unit-time. An IP is blocked the moment it crosses ANY
tier's threshold within that tier's window, checked shortest-window-first
(cheapest/most-obvious case first). See the comment on TIERS below for the
exact numbers and the reasoning behind each one.
"""

import argparse
import subprocess
import shutil

from storage import (
    init_db, record_strike, count_recent_events,
    set_blocked, unblock, is_blocked, get_blocklist, clear_blocklist,
)

# Each tier: (window_seconds, threshold, human-readable label).
# MUST stay sorted shortest-window-first — evaluate_and_maybe_block relies
# on that order to check cheapest/most-obvious cases first.
#
# Threshold RISES with window size, while the implied per-hour RATE FALLS —
# that's the actual design principle: a burst is far more suspicious than
# the same count spread across hours, so short windows stay strict and long
# windows stay lenient per-unit-time:
#   10s/3    -> ~1080/hr   (obvious burst)
#   30s/4    -> ~480/hr
#   1min/5   -> ~300/hr
#   2min/6   -> ~180/hr
#   5min/8   -> ~96/hr
#   1hr/12   -> ~12/hr
#   5hr/20   -> ~4/hr
#   12hr/25  -> ~2/hr      (deliberately-paced, slow scan)
#   24hr/40  -> ~1.7/hr    (very slow, multi-day-style evasion attempts)
TIERS = [
    (10,      3,  "fast burst"),
    (30,      4,  "30-second pace"),
    (60,      5,  "1-minute pace"),
    (120,     6,  "2-minute pace"),
    (300,     8,  "5-minute pace"),
    (3600,    12, "1-hour pace"),
    (18000,   20, "5-hour pace"),
    (43200,   25, "12-hour scan"),
    (86400,   40, "24-hour scan"),
]


def _format_window(seconds):
    if seconds < 60:
        return f"{seconds}s"
    if seconds < 3600:
        return f"{seconds // 60}min"
    return f"{seconds // 3600}h"


def evaluate_and_maybe_block(source_ip, reason_hint="", enable_os_block=False):
    """
    Call this after logging any event. Walks TIERS shortest-window-first and
    blocks the moment any tier's threshold is met within its window. Still
    also records a lifetime strike count (via record_strike) purely for
    display on the dashboard — the BLOCK DECISION itself is always
    rate-based, never the raw lifetime number.
    Returns True if the IP is now blocked.
    """
    if is_blocked(source_ip):
        return True

    record_strike(source_ip)  # lifetime counter, for display only

    for window_seconds, threshold, label in TIERS:
        count = count_recent_events(source_ip, window_seconds)
        if count >= threshold:
            reason = (f"{count} attempts within {_format_window(window_seconds)} ({label})"
                       + (f" — {reason_hint}" if reason_hint else ""))
            return _apply_block(source_ip, reason, enable_os_block)

    return False


def _apply_block(source_ip, reason, enable_os_block):
    applied_os_block = False
    if enable_os_block:
        applied_os_block = _apply_iptables_drop(source_ip)
    set_blocked(source_ip, reason, os_level=applied_os_block)
    print(f"[entihack] BLOCKED {source_ip} ({reason})"
          f"{' + iptables DROP' if applied_os_block else ''}")
    return True


def _apply_iptables_drop(source_ip):
    """
    Adds a DROP rule for this IP at the OS firewall level. Requires root and
    a Linux system with iptables installed. Fails safe (returns False,
    doesn't crash the app) if unavailable — the app-level block still applies
    either way.
    """
    if shutil.which("iptables") is None:
        print("[entihack] iptables not found — falling back to app-level block only.")
        return False
    try:
        subprocess.run(
            ["iptables", "-C", "INPUT", "-s", source_ip, "-j", "DROP"],
            check=True, capture_output=True,
        )
        return True  # rule already exists
    except subprocess.CalledProcessError:
        pass  # rule doesn't exist yet, fall through to add it
    try:
        subprocess.run(
            ["iptables", "-A", "INPUT", "-s", source_ip, "-j", "DROP"],
            check=True, capture_output=True,
        )
        return True
    except subprocess.CalledProcessError as e:
        print(f"[entihack] Failed to apply iptables rule for {source_ip} "
              f"(are you root?): {e.stderr.decode(errors='replace')}")
        return False
    except FileNotFoundError:
        return False


def _remove_iptables_drop(source_ip):
    if shutil.which("iptables") is None:
        return False
    try:
        subprocess.run(
            ["iptables", "-D", "INPUT", "-s", source_ip, "-j", "DROP"],
            check=True, capture_output=True,
        )
        return True
    except subprocess.CalledProcessError:
        return False


def manual_block(source_ip, reason="manual block", enable_os_block=False):
    applied = _apply_iptables_drop(source_ip) if enable_os_block else False
    set_blocked(source_ip, reason, os_level=applied)


def manual_unblock(source_ip):
    unblock(source_ip)
    _remove_iptables_drop(source_ip)  # harmless no-op if no rule existed


def clear_all():
    """Removes every IP from the blocklist entirely — iptables rules are
    cleaned up first (per-IP, same as a single unblock would), then the
    rows themselves are deleted, so cleared IPs stop showing up in `list`
    altogether rather than lingering as 'watching'."""
    rows = get_blocklist()
    for row in rows:
        if row["os_level_block"]:
            _remove_iptables_drop(row["source_ip"])
    clear_blocklist()
    return len(rows)


def main():
    parser = argparse.ArgumentParser(description="Entihack blocklist management")
    sub = parser.add_subparsers(dest="cmd", required=True)

    sub.add_parser("list").set_defaults(cmd="list")

    p_block = sub.add_parser("block")
    p_block.add_argument("ip")
    p_block.add_argument("--os-level", action="store_true",
                          help="Also apply an iptables DROP rule (needs root)")

    p_unblock = sub.add_parser("unblock")
    p_unblock.add_argument("ip")

    p_clear = sub.add_parser("clear", help="Unblock every IP on the blocklist")
    p_clear.add_argument("-y", "--yes", action="store_true",
                          help="Skip the confirmation prompt")

    args = parser.parse_args()
    init_db()

    if args.cmd == "list":
        for row in get_blocklist():
            status = "BLOCKED" if row["blocked"] else "watching"
            os_flag = " [OS-level]" if row["os_level_block"] else ""
            print(f"{row['source_ip']:>16}  strikes={row['strikes']:<3} {status}{os_flag}  "
                  f"reason={row['blocked_reason'] or '-'}")
    elif args.cmd == "block":
        manual_block(args.ip, reason="manual block via CLI", enable_os_block=args.os_level)
        print(f"Blocked {args.ip}")
    elif args.cmd == "unblock":
        manual_unblock(args.ip)
        print(f"Unblocked {args.ip}")
    elif args.cmd == "clear":
        count = len(get_blocklist())
        if count == 0:
            print("Blocklist is already empty — nothing to clear.")
            return
        if not args.yes:
            print(f"This will permanently remove all {count} IP(s) from the blocklist "
                  f"(they won't show up in 'list' anymore, and any iptables rules are removed too).")
            confirm = input("Type 'yes' to continue: ").strip().lower()
            if confirm != "yes":
                print("Cancelled — nothing was changed.")
                return
        cleared = clear_all()
        print(f"Cleared {cleared} IP(s) from the blocklist.")


if __name__ == "__main__":
    main()
