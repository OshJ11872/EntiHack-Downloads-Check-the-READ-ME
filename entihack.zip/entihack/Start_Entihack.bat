@echo off
REM Start_Entihack.bat
REM
REM Double-click this file to install everything Entihack needs and start
REM it — no typing in a terminal required. A black command window will pop
REM up to show progress; that's normal, you don't need to type into it.
REM
REM Requires Python to be installed from python.org first (one-time setup,
REM same as installing any other program) — if double-clicking this does
REM nothing or shows an error about 'python' not being recognized, that's
REM what's missing.

cd /d "%~dp0"

echo ==================================================
echo  Entihack - starting up
echo ==================================================
echo.
echo Installing required packages (only needed the first time)...
pip install -r requirements.txt --quiet

echo Setting up the local database...
python storage.py

if not exist api_key.txt (
    copy api_key.txt.example api_key.txt >nul
    echo.
    echo Created api_key.txt - open it in Notepad and type your own key on
    echo its own line to enable the Block button. Any text works, no special
    echo format required. You can also skip this for now; everything except
    echo live blocking will still work.
)

echo.
echo Running pre-flight diagnostics...
python diagnostics.py
if errorlevel 1 (
    echo.
    echo Diagnostics found a critical issue - fix it above before continuing.
    pause
    exit /b 1
)

echo.
echo Starting the honeypot, tarpit, API, and dashboard...
start "Entihack - honeypot" /min cmd /c "python honeypot.py > logs_honeypot.txt 2>&1"
start "Entihack - tarpit" /min cmd /c "python tarpit.py > logs_tarpit.txt 2>&1"
start "Entihack - api" /min cmd /c "python api.py --port 5050 > logs_api.txt 2>&1"
start "Entihack - dashboard" /min cmd /c "python dashboard.py > logs_dashboard.txt 2>&1"

timeout /t 2 /nobreak >nul

echo.
echo ==================================================
echo  Entihack is running.
echo  Dashboard:  http://localhost:5000
echo  Live API:   http://localhost:5050
echo ==================================================
echo.
echo Opening the dashboard in your browser...
start http://localhost:5000

echo.
echo Leave the small minimized windows open while you want Entihack running.
echo Use Stop_Entihack.bat to shut everything down later.
echo.
pause
