"""
api.py — the live backend for the "real site with a database and a block
button" version of Entihack.

This is what turns the static HTML viewer into something that shows LIVE
data and can actually block an IP when you click a button — because that
requires code running on a real machine with access to the firewall, which
a static-hosted page can never do by itself. This process is that machine.

WHAT IT EXPOSES:
  GET  /api/sessions    -> recent captured attacks, each with a computed threat_level
  GET  /api/blocklist   -> every IP being tracked, blocked or not
  POST /api/block       -> { "ip": "1.2.3.4", "os_level": false }  — blocks it now
  POST /api/unblock     -> { "ip": "1.2.3.4" }                     — unblocks it

SECURITY — READ BEFORE EXPOSING THIS TO THE INTERNET:
Anyone who can call POST /api/block can make your server refuse traffic
from any IP they name — including, in principle, IPs you don't want
refused. This endpoint is gated by an API key so a random visitor to your
site can't mass-block IPs or grief your firewall. Set your own key:

    export ENTIHACK_API_KEY="something long and random"

Requests to POST endpoints must include header:  X-API-Key: <that value>
If ENTIHACK_API_KEY isn't set, the server refuses to start with blocking
enabled and prints a warning — I'm not defaulting to an open control plane.

CORS is enabled so a separately-hosted frontend (e.g. your Netlify/GitHub
Pages site) can call this API. Restrict --allow-origin in production to
your actual site's URL rather than leaving it wide open.
"""

import os
import sys
import json
import datetime
import argparse
from flask import Flask, request, jsonify
from flask_cors import CORS

from storage import (
    init_db, get_all_sessions, get_blocklist, get_conn
)
from profiler import compute_threat_level
from blocker import manual_block, manual_unblock, evaluate_and_maybe_block

app = Flask(__name__)

KEY_FILE_DEFAULT = os.path.join(os.path.dirname(__file__), "api_key.txt")


def load_api_key(key_file_path):
    """
    Resolves the API key in this order:
      1. ENTIHACK_API_KEY environment variable (wins if set — not overwritten by the file)
      2. A local text file (default: api_key.txt next to this script). Lines starting
         with '#' are treated as comments/placeholders and skipped — so a fresh file
         containing only "#PUT YOUR KEY HERE" is correctly treated as "no key set"
         rather than using that literal text as the key. The first non-comment,
         non-blank line found is used as the key.
    Returns None if neither is present — write actions stay disabled either way.
    """
    env_key = os.environ.get("ENTIHACK_API_KEY")
    if env_key:
        return env_key.strip()

    if os.path.exists(key_file_path):
        with open(key_file_path) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#"):
                    return line

    return None


API_KEY = None  # resolved in main() by calling load_api_key() — env var takes priority over the file


def _require_api_key():
    if not API_KEY:
        return jsonify({"error": "Server has no ENTIHACK_API_KEY configured — write actions are disabled."}), 503
    supplied = request.headers.get("X-API-Key")
    if supplied != API_KEY:
        return jsonify({"error": "Invalid or missing X-API-Key header."}), 401
    return None


def _geo(geo_json):
    if not geo_json:
        return None
    try:
        parsed = json.loads(geo_json)
        g = parsed.get("geo", {})
        result = None
        if not g.get("error"):
            result = {"city": g.get("city"), "country": g.get("country"), "isp": g.get("isp")}

        abuse = parsed.get("abuseipdb", {})
        if abuse and not abuse.get("error") and not abuse.get("skipped"):
            worldwide = {
                "total_reports": abuse.get("total_reports"),
                "abuse_confidence_score": abuse.get("abuse_confidence_score"),
                "num_distinct_reporters": abuse.get("num_distinct_reporters"),
            }
            if result is None:
                result = {}
            result["worldwide"] = worldwide
        return result
    except Exception:
        return None


def _strike_lookup():
    conn = get_conn()
    rows = conn.execute("SELECT source_ip, strikes, blocked FROM blocklist").fetchall()
    conn.close()
    return {r["source_ip"]: (r["strikes"], bool(r["blocked"])) for r in rows}


@app.route("/api/sessions", methods=["GET"])
def api_sessions():
    sessions = get_all_sessions(limit=int(request.args.get("limit", 200)))
    strikes_map = _strike_lookup()

    out = []
    for s in sessions:
        strikes, blocked = strikes_map.get(s["source_ip"], (0, False))
        out.append({
            "id": s["id"],
            "timestamp": datetime.datetime.fromtimestamp(s["timestamp"]).strftime("%Y-%m-%d %H:%M:%S"),
            "source_ip": s["source_ip"],
            "service": s["service"],
            "path_or_target": s["path_or_target"],
            "credentials_tried": json.loads(s.get("credentials_tried") or "[]"),
            "profile_label": s.get("profile_label") or "unclassified",
            "profile_confidence": s.get("profile_confidence") or "low",
            "threat_level": compute_threat_level(s.get("profile_confidence") or "low", strikes, blocked),
            "geo": _geo(s.get("geo_json")),
            "strikes": strikes,
            "blocked": blocked,
        })
    return jsonify({"sessions": out, "count": len(out)})


@app.route("/api/blocklist", methods=["GET"])
def api_blocklist():
    return jsonify({"blocklist": get_blocklist()})


@app.route("/api/block", methods=["POST"])
def api_block():
    err = _require_api_key()
    if err:
        return err
    data = request.get_json(force=True, silent=True) or {}
    ip = data.get("ip")
    if not ip:
        return jsonify({"error": "Missing 'ip'"}), 400
    os_level = bool(data.get("os_level", False))
    manual_block(ip, reason="blocked via dashboard button", enable_os_block=os_level)
    return jsonify({"ok": True, "ip": ip, "blocked": True, "os_level": os_level})


@app.route("/api/unblock", methods=["POST"])
def api_unblock():
    err = _require_api_key()
    if err:
        return err
    data = request.get_json(force=True, silent=True) or {}
    ip = data.get("ip")
    if not ip:
        return jsonify({"error": "Missing 'ip'"}), 400
    manual_unblock(ip)
    return jsonify({"ok": True, "ip": ip, "blocked": False})


@app.route("/api/health", methods=["GET"])
def api_health():
    return jsonify({"ok": True, "auth_configured": bool(API_KEY)})


@app.route("/api/stats", methods=["GET"])
def api_stats():
    """
    Honest, local-only totals for THIS installation. This is deliberately
    NOT labeled "worldwide" — it only knows about attacks and blocks this
    specific server has seen. A genuine cross-installation worldwide count
    would need a separate shared server that multiple Entihack installations
    report into; nothing here fabricates or estimates that number.
    """
    blocklist = get_blocklist()
    conn = get_conn()
    total_events = conn.execute("SELECT COUNT(*) as c FROM sessions").fetchone()["c"]
    unique_ips = conn.execute("SELECT COUNT(DISTINCT source_ip) as c FROM sessions").fetchone()["c"]
    conn.close()
    return jsonify({
        "scope": "local_only",
        "note": "Totals for this Entihack installation only — not a worldwide count.",
        "total_events_logged": total_events,
        "unique_ips_seen": unique_ips,
        "ips_blocked": sum(1 for b in blocklist if b["blocked"]),
        "ips_watching_not_yet_blocked": sum(1 for b in blocklist if not b["blocked"]),
    })


def main():
    global API_KEY
    parser = argparse.ArgumentParser(description="Entihack live API server")
    parser.add_argument("--port", type=int, default=5050)
    parser.add_argument("--allow-origin", default="*",
                         help="CORS origin to allow, e.g. https://yoursite.netlify.app. "
                              "Defaults to '*' for local testing — restrict this before going live.")
    parser.add_argument("--key-file", default=KEY_FILE_DEFAULT,
                         help=f"Path to a text file containing the API key, used only if "
                              f"ENTIHACK_API_KEY isn't set (default: {KEY_FILE_DEFAULT})")
    args = parser.parse_args()

    CORS(app, resources={r"/api/*": {"origins": args.allow_origin}})

    API_KEY = load_api_key(args.key_file)

    if not API_KEY:
        print("WARNING: No API key found (checked ENTIHACK_API_KEY env var, then "
              f"{args.key_file}). GET endpoints will work, but block/unblock (POST) "
              "will refuse all requests until you set one of:")
        print('  export ENTIHACK_API_KEY="something-long-and-random"')
        print(f'  echo "something-long-and-random" > {args.key_file}')
    elif os.environ.get("ENTIHACK_API_KEY"):
        print("Using API key from ENTIHACK_API_KEY environment variable.")
    else:
        print(f"Using API key from file: {args.key_file}")

    init_db()
    app.run(host="0.0.0.0", port=args.port, debug=False)


if __name__ == "__main__":
    main()
