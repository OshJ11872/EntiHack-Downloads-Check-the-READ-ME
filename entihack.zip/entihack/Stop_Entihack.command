#!/bin/bash
# Stop_Entihack.command
#
# Double-click this to stop everything Start_Entihack.command started.

cd "$(dirname "$0")"

echo "Stopping Entihack..."
# Match on filename only, not "python3 <file>" — on some Mac Python installs
# (notably Homebrew's framework build), the OS reports the running process's
# command line starting with "Python" rather than literally "python3", which
# made the old "python3 honeypot.py" pattern silently match nothing at all.
pkill -f "honeypot\.py" 2>/dev/null
pkill -f "tarpit\.py" 2>/dev/null
pkill -f "api\.py" 2>/dev/null
pkill -f "dashboard\.py" 2>/dev/null

echo "Stopped. Any IPs that were blocked stay blocked (they're saved in data/entihack.db) —"
echo "run Start_Entihack.command again any time to pick back up where you left off."
echo ""
read -p "Press Enter to close this window... "
