"""
tarpit.py — the "maze": a deception layer that wastes an automated scanner's
time by generating an endless set of fake, linked pages/endpoints.

HOW THIS DIFFERS FROM AN ATTACK:
This only ever responds to requests the visitor makes to YOUR server. It never
opens outbound connections to them, never sends code for their machine to
execute, and never touches anything outside this process. That's what keeps
it in "defensive deception" territory (a long-established technique — see
tarpits like LaBrea, or deception platforms in general) rather than the
"send commands to the hacker" idea from the original request, which would
cross into unauthorized access of their system.

WHAT IT DOES:
- Every path returns a plausible-looking fake page (directory listing, fake
  admin panel, fake config file, etc.) with links to more fake paths, so a
  scanner that follows links gets stuck crawling a maze that goes nowhere.
- Responses are deliberately slow (configurable delay) to consume the
  scanner's time/connection pool.
- Every hit is logged the same way the honeypot logs are, including a
  profiler guess.

Requires: Flask (pip install flask --break-system-packages)
"""

import random
import time
import argparse
from flask import Flask, request, Response

from storage import init_db, log_event, update_profile, update_geo, is_blocked
from profiler import profile_event
from intel import full_lookup
from blocker import evaluate_and_maybe_block
import threading

app = Flask(__name__)
OS_LEVEL_BLOCK = False  # set from CLI flag in main()

FAKE_DIR_NAMES = ["backup", "config", "admin", "old_site", "uploads", "db_dump", "internal", "logs"]
FAKE_FILE_NAMES = ["credentials.txt.bak", "settings.php.old", "dump.sql", "id_rsa", ".env.save"]


def fake_directory_listing(path):
    entries = random.sample(FAKE_DIR_NAMES, k=3) + random.sample(FAKE_FILE_NAMES, k=2)
    links = "".join(f'<li><a href="{path.rstrip("/")}/{e}">{e}</a></li>' for e in entries)
    return f"<html><body><h3>Index of {path}</h3><ul>{links}</ul></body></html>"


@app.route("/", defaults={"path": ""}, methods=["GET", "POST"])
@app.route("/<path:path>", methods=["GET", "POST"])
def catch_all(path):
    ip = request.remote_addr

    if is_blocked(ip):
        # Blocked IPs get an immediate, minimal response — no maze content,
        # no delay, nothing that could be mistaken for engagement.
        return Response(status=403)

    full_path = "/" + path
    raw = f"{request.method} {full_path} UA={request.headers.get('User-Agent','')} DATA={request.get_data(as_text=True)[:500]}"

    creds = []
    if request.form.get("username") or request.form.get("password"):
        creds.append({"user": request.form.get("username", ""), "pass": request.form.get("password", "")})

    row_id = log_event(ip, "tarpit", raw_data=raw, path_or_target=full_path, credentials_tried=creds)

    label, confidence = profile_event({
        "service": "tarpit", "path_or_target": full_path,
        "raw_data": raw, "credentials_tried": creds,
    })
    update_profile(row_id, label, confidence)
    evaluate_and_maybe_block(ip, reason_hint=label, enable_os_block=OS_LEVEL_BLOCK)

    threading.Thread(target=lambda: update_geo(row_id, full_lookup(ip)), daemon=True).start()

    # Deliberate delay to waste automated tooling's time.
    time.sleep(random.uniform(1.5, 4.0))

    body = fake_directory_listing(full_path)
    return Response(body, mimetype="text/html")


def main():
    parser = argparse.ArgumentParser(description="Entihack tarpit/maze server")
    parser.add_argument("--port", type=int, default=8888)
    parser.add_argument("--enable-os-block", action="store_true",
                         help="Also apply iptables DROP rules for auto-blocked IPs (Linux, requires root).")
    args = parser.parse_args()

    global OS_LEVEL_BLOCK
    OS_LEVEL_BLOCK = args.enable_os_block

    init_db()
    app.run(host="0.0.0.0", port=args.port, threaded=True)


if __name__ == "__main__":
    main()
