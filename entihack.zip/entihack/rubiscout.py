"""
rubiscout.py — checks a suspicious email against Rubiscout
(https://rubiscout.com), a real email header/phishing analyzer with a
documented API. Verified directly against their docs (https://rubiscout.com/docs)
before writing this — not guessed at.

This is a STANDALONE tool, separate from the honeypot/IP-blocking pipeline —
it analyzes an email YOU paste in or point at a file, not something that
runs automatically against honeypot traffic (the honeypot doesn't handle
email at all).

Setup:
    cp rubiscout_key.txt.example rubiscout_key.txt
    # then add your key (get one free at https://rubiscout.com/dashboard)
    # below the placeholder comment, same pattern as api_key.txt

Usage:
    python3 rubiscout.py suspicious.eml
    cat suspicious.eml | python3 rubiscout.py -

Real endpoint used (per Rubiscout's own docs):
    POST https://rubiscout.com/api/v1/analyze
    Headers: Authorization: Bearer <key>, Content-Type: application/json
    Body: {"header": "<raw email text, headers or full email, max 500KB>"}
Rate limits per Rubiscout's docs: 60 requests/hour, 200/day per key.
"""

import os
import sys
import json
import urllib.request
import urllib.error

ANALYZE_URL = "https://rubiscout.com/api/v1/analyze"


def load_rubiscout_key(key_file_path=None):
    """Same pattern as api_key.txt / abuseipdb_key.txt: env var first, then a local file, # lines ignored."""
    env_key = os.environ.get("RUBISCOUT_API_KEY")
    if env_key:
        return env_key.strip()

    path = key_file_path or os.path.join(os.path.dirname(__file__), "rubiscout_key.txt")
    if os.path.exists(path):
        with open(path) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#"):
                    return line
    return None


def analyze_email(email_text: str, api_key=None, timeout=15) -> dict:
    """
    Submits raw email headers or a full email to Rubiscout for analysis.
    Returns the parsed JSON response on success, or a dict with an 'error'
    key on failure — never fabricates a verdict.
    """
    key = api_key or load_rubiscout_key()
    if not key:
        return {"error": "No Rubiscout API key configured. Get a free key at "
                          "https://rubiscout.com/dashboard, then set RUBISCOUT_API_KEY "
                          "or add it to rubiscout_key.txt."}

    if len(email_text.encode("utf-8")) > 500_000:
        return {"error": "Email exceeds Rubiscout's 500KB limit for this endpoint."}

    payload = json.dumps({"header": email_text}).encode("utf-8")
    req = urllib.request.Request(
        ANALYZE_URL,
        data=payload,
        headers={
            "Authorization": f"Bearer {key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        body = e.read().decode(errors="replace")
        if e.code == 429:
            return {"error": f"Rate limited by Rubiscout (60/hr, 200/day per key). {body}"}
        return {"error": f"HTTP {e.code}: {body}"}
    except (urllib.error.URLError, TimeoutError, Exception) as e:
        return {"error": str(e)}


def _print_summary(result: dict):
    if "error" in result:
        print(f"Error: {result['error']}")
        return

    print(f"Verdict: {result.get('verdict', '?')}")
    print(f"Risk score: {result.get('riskScore', '?')}")
    print(f"Summary: {result.get('summary', '?')}")
    reasoning = result.get("riskReasoning") or []
    if reasoning:
        print("\nWhy:")
        for r in reasoning:
            print(f"  - {r}")
    recs = result.get("recommendations") or []
    if recs:
        print("\nRecommendations:")
        for r in recs:
            print(f"  - {r}")
    fields = result.get("fields") or {}
    if fields:
        print(f"\nFrom: {fields.get('from', '?')}  |  Reply-To: {fields.get('replyTo', '?')}")
    print(f"\nSPF: {result.get('spf_result','?')}  DKIM: {result.get('dkim_result','?')}  DMARC: {result.get('dmarc_result','?')}")
    ip_country = result.get("ipCountry") or {}
    if ip_country:
        print(f"Originating IP country: {ip_country.get('name', '?')}")
    if result.get("id"):
        print(f"\nStored analysis ID: {result['id']} (retrieve later via Rubiscout's GET /analyses/:id)")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 rubiscout.py <file.eml>   (or: cat file.eml | python3 rubiscout.py -)")
        sys.exit(1)

    if sys.argv[1] == "-":
        email_text = sys.stdin.read()
    else:
        with open(sys.argv[1]) as f:
            email_text = f.read()

    result = analyze_email(email_text)
    _print_summary(result)
