"""
backup.py — protects your captured data and keys against accidental loss
when updating to a new version of Entihack.

WHAT THIS BACKS UP (the things that are NEVER included in any Entihack
zip, and therefore the only things a version update could ever destroy):
  - data/entihack.db      (all your captured attacks + blocklist)
  - api_key.txt           (if you've set one)
  - abuseipdb_key.txt     (if you've set one)
  - exports/              (any reports you've generated)

WHY THIS EXISTS:
Swapping in a new entihack_viewer.html is always safe — it's a standalone
file with no connection to your data. Extracting a new zip INTO your
existing folder is also safe, since the zip never contains these files, so
it can't overwrite them. The only real risk is deleting your whole folder
before extracting a new version, which would take your data down with it
since nothing else has a copy. This tool gives you that copy.

USAGE:
  python3 backup.py create              # makes a timestamped backup .zip
  python3 backup.py restore <file.zip>  # restores a backup into place
  python3 backup.py list                # shows existing backups
"""

import os
import sys
import zipfile
import shutil
import datetime

BASE_DIR = os.path.dirname(__file__)
BACKUP_DIR = os.path.join(BASE_DIR, "backups")

# Exactly the files/folders that are excluded from every Entihack zip —
# i.e. the only things a version update could ever put at risk.
ITEMS_TO_BACKUP = [
    "data/entihack.db",
    "api_key.txt",
    "abuseipdb_key.txt",
    "exports",
]


def create_backup():
    os.makedirs(BACKUP_DIR, exist_ok=True)
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = os.path.join(BACKUP_DIR, f"entihack_backup_{timestamp}.zip")

    found_anything = False
    with zipfile.ZipFile(backup_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for item in ITEMS_TO_BACKUP:
            full_path = os.path.join(BASE_DIR, item)
            if os.path.isfile(full_path):
                zf.write(full_path, arcname=item)
                found_anything = True
            elif os.path.isdir(full_path):
                for root, _, files in os.walk(full_path):
                    for f in files:
                        fp = os.path.join(root, f)
                        arcname = os.path.relpath(fp, BASE_DIR)
                        zf.write(fp, arcname=arcname)
                        found_anything = True

    if not found_anything:
        os.remove(backup_path)
        print("Nothing to back up yet — no data/entihack.db, key files, or "
              "exports/ found. Run this again after you've used Entihack "
              "for a bit, or before updating to a new version just in case.")
        return None

    print(f"Backup created: {backup_path}")
    print("Keep this somewhere safe — it contains your API keys in plain text "
          "if you've set any, so treat it like a password file.")
    return backup_path


def restore_backup(backup_file):
    if not os.path.exists(backup_file):
        print(f"Backup file not found: {backup_file}")
        return

    print(f"About to restore from: {backup_file}")
    print("This will overwrite any current data/entihack.db, key files, and "
          "exports/ with the versions inside this backup.")
    confirm = input("Type 'yes' to continue: ").strip().lower()
    if confirm != "yes":
        print("Cancelled — nothing was changed.")
        return

    with zipfile.ZipFile(backup_file, "r") as zf:
        zf.extractall(BASE_DIR)

    print("Restore complete.")


def list_backups():
    if not os.path.isdir(BACKUP_DIR):
        print("No backups yet. Run: python3 backup.py create")
        return
    backups = sorted(os.listdir(BACKUP_DIR))
    if not backups:
        print("No backups yet. Run: python3 backup.py create")
        return
    print("Existing backups:")
    for b in backups:
        full = os.path.join(BACKUP_DIR, b)
        size_kb = os.path.getsize(full) / 1024
        print(f"  {b}  ({size_kb:.1f} KB)")


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)

    command = sys.argv[1]
    if command == "create":
        create_backup()
    elif command == "restore":
        if len(sys.argv) < 3:
            print("Usage: python3 backup.py restore <backup_file.zip>")
            sys.exit(1)
        restore_backup(sys.argv[2])
    elif command == "list":
        list_backups()
    else:
        print(__doc__)
        sys.exit(1)


if __name__ == "__main__":
    main()
