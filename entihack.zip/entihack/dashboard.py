"""
dashboard.py — simple web dashboard to view what Entihack has captured.

Run: python3 dashboard.py
Then open http://localhost:5000
"""

import json
from flask import Flask, render_template_string

from storage import init_db, get_all_sessions, get_session, update_ai_summary, get_blocklist
from ai_explainer import explain_session

app = Flask(__name__)

TEMPLATE = """
<!doctype html>
<html>
<head>
<title>Entihack Dashboard</title>
<style>
  body { font-family: system-ui, sans-serif; background: #0f1115; color: #e6e6e6; margin: 0; padding: 24px; }
  h1 { color: #4fd1c5; }
  table { width: 100%; border-collapse: collapse; margin-top: 16px; }
  th, td { text-align: left; padding: 8px 12px; border-bottom: 1px solid #2a2d34; font-size: 14px; }
  th { color: #9aa5b1; text-transform: uppercase; font-size: 11px; }
  .badge { padding: 2px 8px; border-radius: 4px; font-size: 12px; }
  .low { background: #3a3320; color: #e0c26a; }
  .medium { background: #3a2a20; color: #e08a4f; }
  .high { background: #3a2020; color: #e05f5f; }
  .empty { color: #666; padding: 40px; text-align: center; }
  code { color: #7fd3ff; }
</style>
</head>
<body>
<h1>Entihack — Captured Sessions</h1>
<p>Heuristic profiling below is a best-guess triage label, not a confirmed identification. IP geolocation is approximate and often reflects hosting/VPN infrastructure rather than a physical location.</p>
{% if sessions %}
<table>
<tr><th>Time</th><th>Source IP</th><th>Service</th><th>Target/Path</th><th>Profile (heuristic)</th><th>Geo (approx.)</th><th>Worldwide reports</th></tr>
{% for s in sessions %}
<tr>
  <td>{{ s.timestamp_fmt }}</td>
  <td><code>{{ s.source_ip }}</code></td>
  <td>{{ s.service }}</td>
  <td>{{ s.path_or_target }}</td>
  <td><span class="badge {{ s.profile_confidence or 'low' }}">{{ s.profile_label or 'unclassified' }}</span></td>
  <td>{{ s.geo_summary }}</td>
  <td>{{ s.worldwide_summary }}</td>
</tr>
{% endfor %}
</table>
{% else %}
<div class="empty">No captures yet. Start honeypot.py or tarpit.py and probe them to see data here.</div>
{% endif %}

<h1 style="margin-top:40px;">Blocklist</h1>
<p>IPs here have had their connections refused by this server after repeat suspicious activity. Nothing on this list has anything sent to it — it's a refuse-list, not a target list.</p>
{% if blocklist %}
<table>
<tr><th>IP</th><th>Strikes</th><th>Status</th><th>OS-level (iptables)</th><th>Reason</th></tr>
{% for b in blocklist %}
<tr>
  <td><code>{{ b.source_ip }}</code></td>
  <td>{{ b.strikes }}</td>
  <td>{{ 'BLOCKED' if b.blocked else 'watching' }}</td>
  <td>{{ 'yes' if b.os_level_block else 'no' }}</td>
  <td>{{ b.blocked_reason or '-' }}</td>
</tr>
{% endfor %}
</table>
{% else %}
<div class="empty">No IPs tracked yet.</div>
{% endif %}
</body>
</html>
"""


def _geo_summary(geo_json):
    if not geo_json:
        return "—"
    try:
        g = json.loads(geo_json).get("geo", {})
        if g.get("error"):
            return f"lookup failed: {g['error']}"
        return f"{g.get('city','?')}, {g.get('country','?')} ({g.get('isp','?')})"
    except Exception:
        return "—"


def _worldwide_summary(geo_json):
    """
    Real, community-reported data from AbuseIPDB — not something Entihack
    computed itself. Only shown when a key is configured; otherwise says so
    plainly rather than showing a blank or fabricated number.
    """
    if not geo_json:
        return "—"
    try:
        abuse = json.loads(geo_json).get("abuseipdb", {})
        if abuse.get("skipped"):
            return "no AbuseIPDB key set"
        if abuse.get("error"):
            return f"lookup failed"
        if not abuse:
            return "—"
        return (f"{abuse.get('total_reports','?')} reports "
                f"({abuse.get('abuse_confidence_score','?')}% confidence) "
                f"from {abuse.get('num_distinct_reporters','?')} reporters")
    except Exception:
        return "—"


@app.route("/")
def index():
    import datetime
    sessions = get_all_sessions()
    for s in sessions:
        s["timestamp_fmt"] = datetime.datetime.fromtimestamp(s["timestamp"]).strftime("%Y-%m-%d %H:%M:%S")
        s["geo_summary"] = _geo_summary(s.get("geo_json"))
        s["worldwide_summary"] = _worldwide_summary(s.get("geo_json"))
    blocklist = get_blocklist()
    return render_template_string(TEMPLATE, sessions=sessions, blocklist=blocklist)


if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=5000, debug=False)
