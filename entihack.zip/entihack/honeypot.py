"""
honeypot.py — passive capture honeypot.

WHAT THIS DOES:
- Opens fake, low-interaction services (fake SSH banner, fake HTTP login page)
  on ports you choose.
- Anyone/anything that connects gets logged: source IP, port, timestamp, any
  data they send (e.g. usernames/passwords tried, HTTP paths requested).
- It does NOT send anything back to the connecting machine other than a
  generic banner/fake page. It never opens a connection TO the attacker,
  never scans them, and never sends commands to their system. That would be
  unauthorized access to a third-party system and is illegal even if they
  attacked first — this tool only ever listens and records.

RUN ON: your own machine or a server/VPS you control. Do not deploy this
in a way that could be mistaken for, or interfere with, real services other
people depend on.

LEGAL NOTE (verify for your jurisdiction): operating a honeypot on
infrastructure you own/control and logging incoming connection attempts is
standard, legal defensive security practice in the US and most jurisdictions.
I'm not a lawyer and this isn't legal advice — if you plan to run this
somewhere with shared/business infrastructure, or store data on identifiable
people, check applicable wiretap/data-protection law (e.g. ECPA in the US,
GDPR if EU-connected data is involved) first.
"""

import socket
import threading
import time
import re
import argparse

from storage import init_db, log_event, update_profile, update_geo, is_blocked
from profiler import profile_event
from intel import full_lookup
from blocker import evaluate_and_maybe_block

MAX_RECV = 4096


def handle_fake_ssh(conn, addr):
    ip, port = addr
    if is_blocked(ip):
        # Blocked IPs get nothing at all — no banner, no data. Just a closed
        # connection, exactly like a firewall drop. We never send anything
        # to them beyond that.
        conn.close()
        return
    try:
        conn.sendall(b"SSH-2.0-OpenSSH_8.9\r\n")
        conn.settimeout(10)
        data = conn.recv(MAX_RECV)
        text = data.decode(errors="replace")

        # Very naive "credential" extraction placeholder — real SSH auth is
        # binary/encrypted; a genuine SSH honeypot needs a proper SSH server
        # implementation (e.g. the `paramiko` library) to actually capture
        # login attempts. This raw-socket version only captures the initial
        # handshake bytes, which is enough to fingerprint scanners but NOT
        # enough to extract real usernames/passwords. Documented honestly
        # here rather than faking that capability.
        creds = []

        row_id = log_event(ip, "fake-ssh", source_port=port, raw_data=text,
                            path_or_target="ssh-handshake", credentials_tried=creds)
        _profile_and_geo(row_id, "fake-ssh", "ssh-handshake", text, creds, ip)
    except Exception:
        pass
    finally:
        conn.close()


def handle_fake_http(conn, addr):
    ip, port = addr
    if is_blocked(ip):
        conn.close()
        return
    try:
        conn.settimeout(10)
        data = conn.recv(MAX_RECV)
        text = data.decode(errors="replace")

        # Parse the request line and any obviously posted form fields.
        first_line = text.splitlines()[0] if text else ""
        m = re.match(r"(GET|POST|PUT) (\S+) HTTP", first_line)
        path = m.group(2) if m else "unknown"

        creds = []
        user_m = re.search(r"username=([^&\s]+)", text)
        pass_m = re.search(r"password=([^&\s]+)", text)
        if user_m or pass_m:
            creds.append({
                "user": user_m.group(1) if user_m else "",
                "pass": pass_m.group(1) if pass_m else "",
            })

        # Serve a generic fake login page — never anything attacker-specific
        # that could be mistaken for an exploit or callback.
        body = (
            b"<html><body><h2>Admin Login</h2>"
            b"<form method='POST'><input name='username'><input name='password' type='password'>"
            b"<button>Sign in</button></form></body></html>"
        )
        response = (
            b"HTTP/1.1 200 OK\r\n"
            b"Content-Type: text/html\r\n"
            b"Content-Length: " + str(len(body)).encode() + b"\r\n\r\n" + body
        )
        conn.sendall(response)

        row_id = log_event(ip, "fake-http", source_port=port, raw_data=text,
                            path_or_target=path, credentials_tried=creds)
        _profile_and_geo(row_id, "fake-http", path, text, creds, ip)
    except Exception:
        pass
    finally:
        conn.close()


def _profile_and_geo(row_id, service, path, raw, creds, ip):
    label, confidence = profile_event({
        "service": service, "path_or_target": path,
        "raw_data": raw, "credentials_tried": creds,
    })
    update_profile(row_id, label, confidence)
    evaluate_and_maybe_block(ip, reason_hint=label, enable_os_block=OS_LEVEL_BLOCK)

    def _bg_geo():
        geo = full_lookup(ip)
        update_geo(row_id, geo)

    threading.Thread(target=_bg_geo, daemon=True).start()


OS_LEVEL_BLOCK = False  # set from CLI flag in main()


def serve(port, handler, host="0.0.0.0"):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind((host, port))
    s.listen(20)
    print(f"[entihack] listening on {host}:{port}")
    while True:
        conn, addr = s.accept()
        threading.Thread(target=handler, args=(conn, addr), daemon=True).start()


def main():
    parser = argparse.ArgumentParser(description="Entihack honeypot listener")
    parser.add_argument("--ssh-port", type=int, default=2222,
                         help="Fake SSH port (default 2222; use a non-privileged port unless run as root)")
    parser.add_argument("--http-port", type=int, default=8080,
                         help="Fake HTTP login port (default 8080)")
    parser.add_argument("--enable-os-block", action="store_true",
                         help="Also apply iptables DROP rules for auto-blocked IPs "
                              "(Linux, requires root). Without this flag, blocking is "
                              "app-level only — still fully effective for this app, "
                              "just not enforced at the OS firewall.")
    args = parser.parse_args()

    global OS_LEVEL_BLOCK
    OS_LEVEL_BLOCK = args.enable_os_block

    init_db()
    t1 = threading.Thread(target=serve, args=(args.ssh_port, handle_fake_ssh), daemon=True)
    t2 = threading.Thread(target=serve, args=(args.http_port, handle_fake_http), daemon=True)
    t1.start()
    t2.start()
    print("Entihack honeypot running. Ctrl+C to stop.")
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nStopping.")


if __name__ == "__main__":
    main()
