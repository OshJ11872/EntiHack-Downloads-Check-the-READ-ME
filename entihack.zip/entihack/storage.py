"""
storage.py — shared SQLite storage for Entihack.

All components (honeypot, tarpit, dashboard) write/read through this module
so there's a single source of truth: data/entihack.db
"""

import sqlite3
import json
import time
import os

DB_PATH = os.path.join(os.path.dirname(__file__), "data", "entihack.db")


def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = get_conn()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp REAL NOT NULL,
            source_ip TEXT NOT NULL,
            source_port INTEGER,
            service TEXT,               -- e.g. 'fake-ssh', 'fake-http', 'tarpit'
            raw_data TEXT,              -- whatever bytes/text they sent, truncated
            path_or_target TEXT,        -- e.g. HTTP path, or username tried
            credentials_tried TEXT,     -- JSON list of {user,pass} if applicable
            profile_label TEXT,         -- heuristic guess, e.g. 'credential stuffing'
            profile_confidence TEXT,    -- 'low' | 'medium' | 'high' — always heuristic
            geo_json TEXT,              -- cached IP geolocation/WHOIS result
            ai_summary TEXT             -- optional plain-language summary
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS blocklist (
            source_ip TEXT PRIMARY KEY,
            strikes INTEGER NOT NULL DEFAULT 0,
            first_seen REAL NOT NULL,
            last_seen REAL NOT NULL,
            blocked INTEGER NOT NULL DEFAULT 0,   -- 0/1
            blocked_at REAL,
            blocked_reason TEXT,
            os_level_block INTEGER NOT NULL DEFAULT 0,  -- whether an iptables rule was also applied
            cooldown_until REAL,                  -- if set and in the future, IP is in temporary cooldown
            cooldown_count INTEGER NOT NULL DEFAULT 0  -- how many cooldowns this IP has already had
        )
    """)
    conn.commit()
    conn.close()


def log_event(source_ip, service, source_port=None, raw_data="", path_or_target="",
              credentials_tried=None):
    conn = get_conn()
    conn.execute(
        """INSERT INTO sessions
           (timestamp, source_ip, source_port, service, raw_data, path_or_target, credentials_tried)
           VALUES (?, ?, ?, ?, ?, ?, ?)""",
        (
            time.time(),
            source_ip,
            source_port,
            service,
            (raw_data or "")[:2000],  # cap stored size
            path_or_target,
            json.dumps(credentials_tried or []),
        ),
    )
    conn.commit()
    row_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    conn.close()
    return row_id


def update_profile(row_id, label, confidence):
    conn = get_conn()
    conn.execute(
        "UPDATE sessions SET profile_label = ?, profile_confidence = ? WHERE id = ?",
        (label, confidence, row_id),
    )
    conn.commit()
    conn.close()


def update_geo(row_id, geo_dict):
    conn = get_conn()
    conn.execute(
        "UPDATE sessions SET geo_json = ? WHERE id = ?",
        (json.dumps(geo_dict), row_id),
    )
    conn.commit()
    conn.close()


def update_ai_summary(row_id, summary_text):
    conn = get_conn()
    conn.execute(
        "UPDATE sessions SET ai_summary = ? WHERE id = ?",
        (summary_text, row_id),
    )
    conn.commit()
    conn.close()


def get_all_sessions(limit=200):
    conn = get_conn()
    rows = conn.execute(
        "SELECT * FROM sessions ORDER BY timestamp DESC LIMIT ?", (limit,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_session(row_id):
    conn = get_conn()
    row = conn.execute("SELECT * FROM sessions WHERE id = ?", (row_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def count_recent_events(source_ip, window_seconds):
    """
    Counts how many logged events this IP has triggered in the last
    `window_seconds`. This is what makes blocking rate-based instead of a
    raw lifetime count — 3 attempts spread across a week looks nothing like
    3 attempts in 2 seconds, and only the second one is a strong automation
    signal.
    """
    conn = get_conn()
    cutoff = time.time() - window_seconds
    row = conn.execute(
        "SELECT COUNT(*) as c FROM sessions WHERE source_ip = ? AND timestamp >= ?",
        (source_ip, cutoff),
    ).fetchone()
    conn.close()
    return row["c"]


def record_strike(source_ip):
    """
    Increments the strike counter for an IP (creating the row if new) and
    returns the updated strike count. Does NOT block on its own — the caller
    (blocklist.py) decides the threshold.
    """
    conn = get_conn()
    now = time.time()
    row = conn.execute("SELECT strikes FROM blocklist WHERE source_ip = ?", (source_ip,)).fetchone()
    if row is None:
        conn.execute(
            "INSERT INTO blocklist (source_ip, strikes, first_seen, last_seen) VALUES (?, 1, ?, ?)",
            (source_ip, now, now),
        )
        strikes = 1
    else:
        strikes = row["strikes"] + 1
        conn.execute(
            "UPDATE blocklist SET strikes = ?, last_seen = ? WHERE source_ip = ?",
            (strikes, now, source_ip),
        )
    conn.commit()
    conn.close()
    return strikes


def set_blocked(source_ip, reason, os_level=False):
    conn = get_conn()
    conn.execute(
        """UPDATE blocklist SET blocked = 1, blocked_at = ?, blocked_reason = ?, os_level_block = ?
           WHERE source_ip = ?""",
        (time.time(), reason, int(os_level), source_ip),
    )
    conn.commit()
    conn.close()


def unblock(source_ip):
    conn = get_conn()
    conn.execute(
        "UPDATE blocklist SET blocked = 0, os_level_block = 0 WHERE source_ip = ?",
        (source_ip,),
    )
    conn.commit()
    conn.close()


def is_blocked(source_ip):
    conn = get_conn()
    row = conn.execute("SELECT blocked FROM blocklist WHERE source_ip = ?", (source_ip,)).fetchone()
    conn.close()
    return bool(row and row["blocked"])


def set_cooldown(source_ip, until_timestamp):
    """Puts an IP into temporary cooldown until the given timestamp, and increments its cooldown_count."""
    conn = get_conn()
    row = conn.execute("SELECT cooldown_count FROM blocklist WHERE source_ip = ?", (source_ip,)).fetchone()
    new_count = (row["cooldown_count"] if row else 0) + 1
    conn.execute(
        "UPDATE blocklist SET cooldown_until = ?, cooldown_count = ? WHERE source_ip = ?",
        (until_timestamp, new_count, source_ip),
    )
    conn.commit()
    conn.close()
    return new_count


def get_cooldown_count(source_ip):
    conn = get_conn()
    row = conn.execute("SELECT cooldown_count FROM blocklist WHERE source_ip = ?", (source_ip,)).fetchone()
    conn.close()
    return row["cooldown_count"] if row else 0


def is_in_cooldown(source_ip):
    """Returns True if this IP is currently within an active cooldown window."""
    conn = get_conn()
    row = conn.execute("SELECT cooldown_until FROM blocklist WHERE source_ip = ?", (source_ip,)).fetchone()
    conn.close()
    if row and row["cooldown_until"]:
        return time.time() < row["cooldown_until"]
    return False


def clear_cooldown(source_ip):
    conn = get_conn()
    conn.execute("UPDATE blocklist SET cooldown_until = NULL WHERE source_ip = ?", (source_ip,))
    conn.commit()
    conn.close()


def get_blocklist():
    conn = get_conn()
    rows = conn.execute("SELECT * FROM blocklist ORDER BY last_seen DESC").fetchall()
    conn.close()
    return [dict(r) for r in rows]


if __name__ == "__main__":
    init_db()
    print(f"Initialized database at {DB_PATH}")
