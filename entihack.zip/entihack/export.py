"""
export.py — writes everything Entihack has captured into a single, portable
JSON report file (plus an optional CSV) that you can move, archive, or open
in the standalone viewer (entihack_viewer.html).

This is a local export only — it does not upload anything anywhere. "Upload
to an app" in this project means: generate this file, then open it in
entihack_viewer.html (or hand it to whatever app/dashboard you want) yourself.
I'm not building an automatic upload to a third-party service, since that
would mean picking a destination and auth method on your behalf — tell me
where you actually want it to go (your own server? a specific dashboard
tool?) and I can wire that destination in specifically.

Each entry documents one captured attack attempt:
  - source IP address
  - timestamp (human-readable + raw)
  - which fake service was hit (fake-ssh / fake-http / tarpit)
  - what path/target was probed
  - credentials tried, if any
  - the heuristic "what we think they were attacking" label + confidence
  - geolocation/WHOIS info, if the lookup succeeded
  - AI plain-language summary, if generated
  - whether that IP was blocked, and after how many strikes
"""

import json
import csv
import os
import time
import argparse
import datetime

from storage import init_db, get_all_sessions, get_blocklist

EXPORT_DIR = os.path.join(os.path.dirname(__file__), "exports")


def _fmt_ts(ts):
    return datetime.datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M:%S")


def build_report(limit=1000):
    sessions = get_all_sessions(limit=limit)
    blocklist = {b["source_ip"]: b for b in get_blocklist()}

    attacks = []
    for s in sessions:
        ip = s["source_ip"]
        geo = {}
        abuse = {}
        if s.get("geo_json"):
            try:
                parsed = json.loads(s["geo_json"])
                geo = parsed.get("geo", {})
                abuse = parsed.get("abuseipdb", {})
            except Exception:
                geo, abuse = {}, {}

        block_info = blocklist.get(ip, {})

        attacks.append({
            "id": s["id"],
            "timestamp": _fmt_ts(s["timestamp"]),
            "timestamp_unix": s["timestamp"],
            "source_ip": ip,
            "service_targeted": s["service"],
            "path_or_target": s["path_or_target"],
            "credentials_tried": json.loads(s.get("credentials_tried") or "[]"),
            "what_we_think_they_were_attacking": {
                "label": s.get("profile_label") or "unclassified",
                "confidence": s.get("profile_confidence") or "low",
                "note": "Heuristic pattern match, not a confirmed identification.",
            },
            "location_estimate": {
                "city": geo.get("city"),
                "country": geo.get("country"),
                "isp_or_org": geo.get("isp"),
                "note": "Approximate, from IP geolocation — often reflects hosting/VPN infrastructure rather than a physical location.",
            } if geo and not geo.get("error") else None,
            "worldwide_reports": {
                "total_reports": abuse.get("total_reports"),
                "abuse_confidence_score": abuse.get("abuse_confidence_score"),
                "num_distinct_reporters": abuse.get("num_distinct_reporters"),
                "note": "From AbuseIPDB — a real, community-reported database, not Entihack-specific. Reflects reports from other systems worldwide, not just yours.",
            } if abuse and not abuse.get("error") and not abuse.get("skipped") else None,
            "ai_summary": s.get("ai_summary"),
            "blocked": bool(block_info.get("blocked")),
            "block_reason": block_info.get("blocked_reason"),
        })

    report = {
        "generated_at": _fmt_ts(time.time()),
        "tool": "Entihack",
        "attack_count": len(attacks),
        "unique_source_ips": len({a["source_ip"] for a in attacks}),
        "blocked_ip_count": sum(1 for a in attacks if a["blocked"]),
        "attacks": attacks,
    }
    return report


def write_json(report, path=None):
    os.makedirs(EXPORT_DIR, exist_ok=True)
    if path is None:
        path = os.path.join(EXPORT_DIR, f"entihack_report_{int(time.time())}.json")
    with open(path, "w") as f:
        json.dump(report, f, indent=2)
    return path


def write_csv(report, path=None):
    os.makedirs(EXPORT_DIR, exist_ok=True)
    if path is None:
        path = os.path.join(EXPORT_DIR, f"entihack_report_{int(time.time())}.csv")
    fields = ["id", "timestamp", "source_ip", "service_targeted", "path_or_target",
              "attack_label", "confidence", "city", "country", "isp_or_org", "blocked"]
    with open(path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for a in report["attacks"]:
            loc = a["location_estimate"] or {}
            writer.writerow({
                "id": a["id"],
                "timestamp": a["timestamp"],
                "source_ip": a["source_ip"],
                "service_targeted": a["service_targeted"],
                "path_or_target": a["path_or_target"],
                "attack_label": a["what_we_think_they_were_attacking"]["label"],
                "confidence": a["what_we_think_they_were_attacking"]["confidence"],
                "city": loc.get("city"),
                "country": loc.get("country"),
                "isp_or_org": loc.get("isp_or_org"),
                "blocked": a["blocked"],
            })
    return path


def main():
    parser = argparse.ArgumentParser(description="Export Entihack captures to a portable report file")
    parser.add_argument("--format", choices=["json", "csv", "both"], default="both")
    parser.add_argument("--limit", type=int, default=1000)
    args = parser.parse_args()

    init_db()
    report = build_report(limit=args.limit)

    if args.format in ("json", "both"):
        p = write_json(report)
        print(f"Wrote {p}  ({report['attack_count']} attacks, {report['unique_source_ips']} unique IPs)")
    if args.format in ("csv", "both"):
        p = write_csv(report)
        print(f"Wrote {p}")


if __name__ == "__main__":
    main()
