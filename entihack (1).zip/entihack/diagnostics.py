"""
diagnostics.py — pre-flight health check, run before starting Entihack.

WHAT "everything should feel surreal" MEANS HERE, HONESTLY:
I've interpreted this as "make the check feel like a satisfying, cinematic
boot sequence" rather than anything literally strange or dreamlike — a
polished, dramatic-but-real systems check, similar to tools like
`flutter doctor` or a spacecraft pre-launch checklist. Every line printed
here reflects a REAL check with a REAL pass/fail result — nothing here is
decorative theater standing in for an actual check.

WHAT IT ACTUALLY CHECKS (all real, all testable):
  1. Python version (3.8+)
  2. Required packages installed (flask, ipwhois, anthropic)
  3. Write access to this folder (needed for data/entihack.db, logs, backups)
  4. Whether the honeypot/tarpit/API ports are already in use
  5. Whether storage.py's database initializes cleanly
  6. Whether personas.py loads without error
  7. Whether an API key is configured (informational, not a failure)

OPTIONAL AI SUMMARY:
If ANTHROPIC_API_KEY is set (same pattern as ai_explainer.py), the raw
results get sent to Claude for a one-paragraph plain-English summary at
the end. This is NOT a "trained" AI — it's the same general-purpose model
ai_explainer.py already uses, just given this specific data to read. If no
key is set, this step is skipped entirely and the raw checklist above is
still complete and useful on its own.
"""

import sys
import os
import socket
import time
import importlib.util

USE_COLOR = sys.stdout.isatty()


def _c(text, code):
    return f"\033[{code}m{text}\033[0m" if USE_COLOR else text


def green(t): return _c(t, "32")
def red(t): return _c(t, "31")
def yellow(t): return _c(t, "33")
def dim(t): return _c(t, "2")
def bold(t): return _c(t, "1")


CHECK_MARK = "✓"
CROSS_MARK = "✗"
WARN_MARK = "!"


def _step(label, delay=0.15):
    print(f"  {dim('...')} {label}", end="", flush=True)
    time.sleep(delay)  # brief pause for a real boot-sequence feel, not fake work


def _pass(msg=""):
    print(f"\r  {green(CHECK_MARK)} {msg or ''}".ljust(70))


def _fail(msg):
    print(f"\r  {red(CROSS_MARK)} {msg}".ljust(70))


def _warn(msg):
    print(f"\r  {yellow(WARN_MARK)} {msg}".ljust(70))


def check_python_version():
    _step("Checking Python version...")
    ok = sys.version_info >= (3, 8)
    version_str = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    if ok:
        _pass(f"Python {version_str} (3.8+ required)")
    else:
        _fail(f"Python {version_str} — need 3.8 or newer")
    return ok


def check_package(name, import_name=None):
    import_name = import_name or name
    _step(f"Checking for {name}...")
    found = importlib.util.find_spec(import_name) is not None
    if found:
        _pass(f"{name} is installed")
    else:
        _fail(f"{name} NOT installed — run: pip install {name} --break-system-packages")
    return found


def check_write_access(base_dir):
    _step("Checking write access to this folder...")
    test_file = os.path.join(base_dir, ".diagnostic_write_test")
    try:
        with open(test_file, "w") as f:
            f.write("test")
        os.remove(test_file)
        _pass("Folder is writable")
        return True
    except Exception as e:
        _fail(f"Cannot write here: {e}")
        return False


def check_port(port, label):
    _step(f"Checking if port {port} ({label}) is free...")
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(1)
    result = s.connect_ex(("127.0.0.1", port))
    s.close()
    if result != 0:
        _pass(f"Port {port} ({label}) is free")
        return True
    else:
        _warn(f"Port {port} ({label}) is already in use — something may already be running")
        return False


def check_database(base_dir):
    _step("Checking database initializes cleanly...")
    try:
        sys.path.insert(0, base_dir)
        from storage import init_db
        init_db()
        _pass("Database OK")
        return True
    except Exception as e:
        _fail(f"Database error: {e}")
        return False


def check_personas(base_dir):
    _step("Checking persona system loads...")
    try:
        sys.path.insert(0, base_dir)
        from personas import PERSONA_NAMES
        _pass(f"Persona system OK ({len(PERSONA_NAMES)} personas available)")
        return True
    except Exception as e:
        _fail(f"Persona system error: {e}")
        return False


def check_api_key(base_dir):
    _step("Checking for a configured API key...")
    env_key = os.environ.get("ENTIHACK_API_KEY")
    key_file = os.path.join(base_dir, "api_key.txt")
    file_has_key = False
    if os.path.exists(key_file):
        with open(key_file) as f:
            for line in f:
                if line.strip() and not line.strip().startswith("#"):
                    file_has_key = True
                    break
    if env_key or file_has_key:
        _pass("API key configured — live Block button will work")
    else:
        _warn("No API key set yet — everything works except the live Block button "
              "(see api_key.txt.example)")
    return True  # informational only, never fails the overall check


def maybe_ai_summary(results):
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        return
    try:
        import anthropic
    except ImportError:
        return

    print(f"\n{dim('Asking Claude to summarize these results...')}")
    try:
        client = anthropic.Anthropic(api_key=api_key)
        summary = "\n".join(f"{k}: {'PASS' if v else 'FAIL'}" for k, v in results.items())
        response = client.messages.create(
            model="claude-sonnet-4-6",  # verify current model name at docs.claude.com
            max_tokens=200,
            messages=[{
                "role": "user",
                "content": f"Here are pre-flight diagnostic results for a honeypot tool called "
                            f"Entihack:\n{summary}\n\nGive a 2-3 sentence plain-English summary "
                            f"of whether it's safe to start, and what to fix first if not."
            }],
        )
        text = "".join(b.text for b in response.content if hasattr(b, "text"))
        print(f"\n{bold('AI summary:')} {text}\n")
    except Exception as e:
        print(f"{dim(f'(AI summary unavailable: {e})')}\n")


def run_diagnostics():
    base_dir = os.path.dirname(os.path.abspath(__file__))

    version_file = os.path.join(base_dir, "VERSION")
    version = "unknown"
    if os.path.exists(version_file):
        with open(version_file) as f:
            version = f.read().strip()

    print(bold("\n═══════════════════════════════════════"))
    print(bold(f"   ENTIHACK v{version} — PRE-FLIGHT DIAGNOSTIC"))
    print(bold("═══════════════════════════════════════\n"))

    results = {}
    results["python_version"] = check_python_version()
    results["flask"] = check_package("flask")
    results["ipwhois"] = check_package("ipwhois")
    results["anthropic"] = check_package("anthropic")
    results["write_access"] = check_write_access(base_dir)
    results["port_2222"] = check_port(2222, "fake SSH")
    results["port_8080"] = check_port(8080, "fake HTTP")
    results["port_8888"] = check_port(8888, "tarpit")
    results["port_5050"] = check_port(5050, "live API")
    results["port_5000"] = check_port(5000, "dashboard")
    results["database"] = check_database(base_dir)
    results["personas"] = check_personas(base_dir)
    results["api_key"] = check_api_key(base_dir)

    hard_failures = [k for k in ("python_version", "flask", "write_access", "database", "personas")
                      if not results.get(k)]

    print(bold("\n═══════════════════════════════════════"))
    if hard_failures:
        print(red(bold(f"   {len(hard_failures)} CRITICAL ISSUE(S) — fix before starting")))
    else:
        print(green(bold("   ALL SYSTEMS GO")))
    print(bold("═══════════════════════════════════════\n"))

    maybe_ai_summary(results)

    return len(hard_failures) == 0


if __name__ == "__main__":
    ok = run_diagnostics()
    sys.exit(0 if ok else 1)
