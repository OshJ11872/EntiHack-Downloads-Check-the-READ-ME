#!/usr/bin/env python3
"""
farm.py — run multiple isolated Entihack instances at once.

Each instance is a fully separate extracted copy (own folder, own database,
own log files) so captures never mix between instances. Ports are offset
per instance so they don't collide with each other or with a normal single
Start_Entihack.command run.

USAGE:
    python3 farm.py start <zip_path> <count>   # extract & launch N instances
    python3 farm.py status                     # show what's running
    python3 farm.py stop                       # stop every instance
"""
import os
import sys
import json
import signal
import zipfile
import subprocess
import argparse

FARM_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "entihack_farm")
STATE_FILE = os.path.join(FARM_DIR, "farm_state.json")

BASE_PORTS = {
    "ssh": 2222,
    "http": 8080,
    "tarpit": 8888,
    "api": 5050,
    "dashboard": 5000,
}


def load_state():
    if os.path.exists(STATE_FILE):
        with open(STATE_FILE) as f:
            return json.load(f)
    return {"instances": []}


def save_state(state):
    os.makedirs(FARM_DIR, exist_ok=True)
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2)


def start(zip_path, count):
    if not os.path.exists(zip_path):
        print(f"Zip not found: {zip_path}")
        sys.exit(1)

    state = load_state()
    if state["instances"]:
        print(f"{len(state['instances'])} instance(s) already running "
              f"according to farm state — run 'stop' first.")
        sys.exit(1)

    os.makedirs(FARM_DIR, exist_ok=True)
    instances = []

    for i in range(count):
        inst_dir = os.path.join(FARM_DIR, f"instance_{i}")
        print(f"[{i}] Extracting into {inst_dir} ...")
        os.makedirs(inst_dir, exist_ok=True)
        with zipfile.ZipFile(zip_path) as zf:
            zf.extractall(inst_dir)
        entihack_dir = os.path.join(inst_dir, "entihack")

        ports = {name: base + i for name, base in BASE_PORTS.items()}
        env = os.environ.copy()
        procs = {}

        def _log(name):
            return open(os.path.join(entihack_dir, f"logs_{name}.txt"), "w")

        procs["honeypot"] = subprocess.Popen(
            ["python3", "honeypot.py", "--ssh-port", str(ports["ssh"]),
             "--http-port", str(ports["http"])],
            cwd=entihack_dir, env=env, stdout=_log("honeypot"), stderr=subprocess.STDOUT,
        )
        procs["tarpit"] = subprocess.Popen(
            ["python3", "tarpit.py", "--port", str(ports["tarpit"])],
            cwd=entihack_dir, env=env, stdout=_log("tarpit"), stderr=subprocess.STDOUT,
        )
        procs["api"] = subprocess.Popen(
            ["python3", "api.py", "--port", str(ports["api"])],
            cwd=entihack_dir, env=env, stdout=_log("api"), stderr=subprocess.STDOUT,
        )
        procs["dashboard"] = subprocess.Popen(
            ["python3", "dashboard.py", "--port", str(ports["dashboard"])],
            cwd=entihack_dir, env=env, stdout=_log("dashboard"), stderr=subprocess.STDOUT,
        )

        instances.append({
            "index": i,
            "dir": entihack_dir,
            "ports": ports,
            "pids": {name: p.pid for name, p in procs.items()},
        })
        print(f"[{i}] dashboard: http://localhost:{ports['dashboard']}  "
              f"api: http://localhost:{ports['api']}")

    state["instances"] = instances
    save_state(state)
    print(f"\nStarted {count} instance(s). "
          f"'python3 farm.py status' to check them, 'python3 farm.py stop' to stop everything.")


def status():
    state = load_state()
    if not state["instances"]:
        print("No instances running (according to farm state).")
        return
    for inst in state["instances"]:
        alive = []
        for name, pid in inst["pids"].items():
            try:
                os.kill(pid, 0)
                alive.append(name)
            except OSError:
                pass
        print(f"[{inst['index']}] {inst['dir']}")
        print(f"     dashboard: http://localhost:{inst['ports']['dashboard']}")
        print(f"     alive: {', '.join(alive) if alive else '(none — may have crashed, check its logs_*.txt)'}")


def stop():
    state = load_state()
    if not state["instances"]:
        print("Nothing to stop.")
        return
    for inst in state["instances"]:
        for name, pid in inst["pids"].items():
            try:
                os.kill(pid, signal.SIGTERM)
                print(f"[{inst['index']}] stopped {name} (pid {pid})")
            except OSError:
                print(f"[{inst['index']}] {name} (pid {pid}) already gone")
    save_state({"instances": []})
    print("All instances stopped. Each instance's own data/entihack.db is untouched "
          "and still sitting in its entihack_farm/instance_N/ folder.")


def main():
    parser = argparse.ArgumentParser(description="Run multiple isolated Entihack instances")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_start = sub.add_parser("start")
    p_start.add_argument("zip_path")
    p_start.add_argument("count", type=int)

    sub.add_parser("status")
    sub.add_parser("stop")

    args = parser.parse_args()
    if args.cmd == "start":
        start(args.zip_path, args.count)
    elif args.cmd == "status":
        status()
    elif args.cmd == "stop":
        stop()


if __name__ == "__main__":
    main()
