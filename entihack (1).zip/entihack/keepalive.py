"""
keepalive.py — a personal uptime watchdog for your own Entihack instance.

Periodically checks that the dashboard and API are actually responding,
logs the result, and (optionally) tries to restart things automatically if
they've gone down. Runs until you stop it with Ctrl+C.

IMPORTANT: this checks the DASHBOARD and API health endpoint only — never
the honeypot (8080) or tarpit (8888) ports. Those two are deliberately
built to flag and rate-limit repeated hits from the same IP (see the FAQ:
"why did my own test request get blocked"), so a keepalive loop hitting
them on a timer would eventually block itself.

This is a personal utility, not part of the public release — nothing here
is required for Entihack itself to work.

USAGE:
    python3 keepalive.py                      # check every 60s, forever
    python3 keepalive.py --interval 300       # check every 5 minutes
    python3 keepalive.py --auto-restart        # try to restart if down
"""

import sys
import os
import time
import argparse
import subprocess
import urllib.request
import urllib.error
from datetime import datetime

DASHBOARD_URL = "http://localhost:5000"
API_HEALTH_URL = "http://localhost:5050/api/health"
BASE_DIR = os.path.dirname(os.path.abspath(__file__))


def _timestamp():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def check_url(url, timeout=5):
    try:
        with urllib.request.urlopen(url, timeout=timeout) as resp:
            return resp.status == 200
    except (urllib.error.URLError, TimeoutError, ConnectionError):
        return False


def check_all():
    dashboard_ok = check_url(DASHBOARD_URL)
    api_ok = check_url(API_HEALTH_URL)
    return dashboard_ok, api_ok


def attempt_restart():
    launcher = os.path.join(BASE_DIR, "Start_Entihack.command")
    if not os.path.exists(launcher):
        # Fall back to Linux launcher if that's what's actually present
        launcher = os.path.join(BASE_DIR, "Start_Entihack_Linux.sh")
    if not os.path.exists(launcher):
        print(f"[{_timestamp()}] Can't auto-restart — no launcher script found.")
        return False
    print(f"[{_timestamp()}] Attempting restart via {os.path.basename(launcher)}...")
    try:
        # Run non-interactively in the background — the launcher normally
        # waits for a keypress at the end, so feed it a blank line instead.
        subprocess.Popen(
            ["bash", launcher],
            cwd=BASE_DIR,
            stdin=subprocess.PIPE,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        ).stdin.close()
        return True
    except Exception as e:
        print(f"[{_timestamp()}] Restart attempt failed: {e}")
        return False


def main():
    parser = argparse.ArgumentParser(description="Entihack keepalive/uptime watchdog")
    parser.add_argument("--interval", type=int, default=60,
                         help="Seconds between checks (default: 60)")
    parser.add_argument("--auto-restart", action="store_true",
                         help="Try to restart Entihack automatically if it's found down")
    args = parser.parse_args()

    print(f"Entihack keepalive watchdog started — checking every {args.interval}s. "
          f"Press Ctrl+C to stop.")
    print(f"Watching: {DASHBOARD_URL} and {API_HEALTH_URL}")
    print("(never pings the honeypot or tarpit — those would rate-limit a repeating bot)\n")

    consecutive_downtime = 0
    try:
        while True:
            dashboard_ok, api_ok = check_all()
            if dashboard_ok and api_ok:
                print(f"[{_timestamp()}] UP — dashboard OK, API OK")
                consecutive_downtime = 0
            else:
                consecutive_downtime += 1
                status = f"dashboard={'OK' if dashboard_ok else 'DOWN'}, api={'OK' if api_ok else 'DOWN'}"
                print(f"[{_timestamp()}] DOWN — {status} (consecutive: {consecutive_downtime})")
                if args.auto_restart:
                    attempt_restart()
            time.sleep(args.interval)
    except KeyboardInterrupt:
        print(f"\n[{_timestamp()}] Stopped by user.")


if __name__ == "__main__":
    main()
